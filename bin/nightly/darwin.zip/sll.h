#ifndef __SLL_H__
#define __SLL_H__ 1
#include <stdarg.h>
#include <stddef.h>
#define __VERSION_STR_(x) #x
#define __VERSION_STR(x) __VERSION_STR_(x)
#define SLL_OBJECT_FUNC_INIT 0
#define SLL_OBJECT_FUNC_DELETE 1
#define SLL_OBJECT_FUNC_COPY 2
#define SLL_OBJECT_FUNC_STRING 3
#define SLL_MAX_OBJECT_FUNC SLL_OBJECT_FUNC_STRING
#define SLL_MAX_SEMAPHORE_INDEX __SLL_U32_MAX
#define SLL_ERROR_NO_FILE_PATH 1
#define SLL_ERROR_UNKNOWN_FD 2
#define SLL_ERROR_SANDBOX 3
#define SLL_ERROR_TOO_LONG 4
#define SLL_ERROR_EOF 5
#define SLL_ERROR_BASE64_PADDING 6
#define SLL_ERROR_BASE64_CHARACTER 7
#define SLL_ERROR_STRING 8
#define SLL_ERROR_UNKNOWN_FUNCTION 9
#define SLL_UNMAPPED_SYSTEM_ERROR 255
#define SLL_ERROR_FLAG_SLL 0
#define SLL_ERROR_FLAG_SYSTEM 0x100
#define SLL_ERROR_GET_TYPE(error) ((error)&0x100)
#define SLL_ERROR_GET_VALUE(error) ((error)&0xff)
#define SLL_ERROR_GET_EXTRA(error) ((error)>>9)
#define SLL_ERROR_FROM_EXTRA(type,extra) ((((sll_error_t)(extra))<<9)|(type))
#define SLL_ERROR_FROM_SANDBOX(flag) SLL_ERROR_FROM_EXTRA(SLL_ERROR_SANDBOX,(flag))
#define SLL_ERROR_FROM_STRING_POINTER(pointer) SLL_ERROR_FROM_EXTRA(SLL_ERROR_STRING,(pointer))
#define SLL_NO_ERROR 0xffffffffffffffffull
#define SLL_VAR_ARG_LIST_TYPE_C 0
#define SLL_VAR_ARG_LIST_TYPE_SLL 1
#define SLL_VAR_ARG_LIST_TYPE_RESERVED0 2
#define SLL_VAR_ARG_INIT_C(va,va_ptr)do{sll_var_arg_list_t* __va=(va);__va->type=SLL_VAR_ARG_LIST_TYPE_C;__va->data.c=(va_ptr);} while (0)
#define SLL_VAR_ARG_INIT_SLL(va,pointer_,count_)do{sll_var_arg_list_t* __va=(va);__va->type=SLL_VAR_ARG_LIST_TYPE_SLL;__va->data.sll.pointer=(pointer_);__va->data.sll.count=(count_);} while (0)
#define SLL_VERSION_MAJOR 0
#define SLL_VERSION_MINOR 7
#define SLL_VERSION_PATCH 24
#define SLL_VERSION_SHA ""
#define SLL_VERSION_FULL_SHA ""
#define SLL_VERSION_TAG ""
#define SLL_VERSION_HAS_SHA 0
#define SLL_VERSION_BUILD_TIME __SLL_TIME_RAW__
#define SLL_VERSION_STRING __VERSION_STR(SLL_VERSION_MAJOR)"."__VERSION_STR(SLL_VERSION_MINOR)"."__VERSION_STR(SLL_VERSION_PATCH)
#define SLL_VERSION ((sll_version_t)((SLL_VERSION_MAJOR<<24)|(SLL_VERSION_MINOR<<16)|SLL_VERSION_PATCH))
#define SLL_GET_MAJOR(v) ((v)>>24)
#define SLL_GET_MINOR(v) (((v)>>16)&0xff)
#define SLL_GET_PATCH(v) ((v)&0xffff)
#define SLL_MAX_SHORT_IDENTIFIER_LENGTH 15
#define SLL_INIT_TLS(out)do{(out)->sz=0;(out)->dt=NULL;} while (0)
#define SLL_INIT_TLS_STRUCT {0,NULL}
#define SLL_MAX_ASSEMBLY_INSTRUCTION_TYPE __SLL_U8_MAX
#define SLL_MAX_INSTRUCTION_INDEX __SLL_U32_MAX
#define SLL_MAX_VARIABLE_INDEX __SLL_U32_MAX
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_POP 0
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_POP_TWO 1
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ROT 2
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ROT_POP 3
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_DUP 4
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_INT 5
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_INT_COMPRESSED 6
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_MINUS_ONE 7
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_ZERO 8
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_ONE 9
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_TWO 10
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_THREE 11
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_FOUR 12
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_FLOAT 13
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_COMPLEX 14
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_CHAR 15
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_EMPTY_STRING 16
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_LABEL 17
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PUSH_STACK 18
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_LOAD 19
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_LOADS 20
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PACK 21
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PACK_ZERO 22
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PACK_ONE 23
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_MAP 24
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_MAP_ZERO 25
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_STORE 26
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_STORE_POP 27
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_STORE_MINUS_ONE 28
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_STORE_ZERO 29
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_STORE_ONE 30
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_STORE_TWO 31
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_STORE_THREE 32
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_STORE_FOUR 33
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_LOOKUP 34
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_LOOKUP_STR 35
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JMP 36
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JB 37
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JBE 38
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JA 39
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JAE 40
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JE 41
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JNE 42
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JZ 43
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JNZ 44
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JSE 45
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JSNE 46
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JI 47
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JNI 48
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_JT 49
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_NOT 50
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_BOOL 51
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_INC 52
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_DEC 53
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ADD 54
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_SUB 55
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_MULT 56
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_DIV 57
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_FDIV 58
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_MOD 59
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_AND 60
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_OR 61
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_XOR 62
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_INV 63
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_SHR 64
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_SHL 65
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_LENGTH 66
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_COPY 67
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_DEEP_COPY 68
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ACCESS 69
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ACCESS_TWO 70
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ACCESS_THREE 71
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ACCESS_VAR 72
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ASSIGN 73
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ASSIGN_TWO 74
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ASSIGN_THREE 75
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_ASSIGN_VAR_ACCESS 76
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_CAST 77
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_CAST_TYPE 78
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_TYPEOF 79
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_NAMEOF 80
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_NAMEOF_TYPE 81
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_DECL 82
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_DECL_ZERO 83
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_NEW 84
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_NEW_DECL 85
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PRINT 86
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PRINT_CHAR 87
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PRINT_STR 88
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_PRINT_VAR 89
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_CALL 90
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_CALL_POP 91
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_CALL_ZERO 92
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_CALL_ONE 93
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_CALL_ARRAY 94
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_REF 95
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RET 96
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RET_INT 97
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RET_ZERO 98
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RET_FLOAT 99
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RET_CHAR 100
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RET_STR 101
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RET_VAR 102
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_DEL 103
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_LOAD_DEL 104
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_THREAD_ID 105
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_THREAD_WAIT 106
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_THREAD_LOCK 107
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_THREAD_SEMAPHORE 108
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_THREAD_BARRIER_EQ 109
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_THREAD_BARRIER_GEQ 110
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_THREAD_EXIT 111
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_READ_BLOCKING 112
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_READ_BLOCKING_CHAR 113
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_CHANGE_STACK 114
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RESERVED0 123
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RESERVED1 124
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RESERVED2 125
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RESERVED3 126
#define SLL_ASSEMBLY_INSTRUCTION_TYPE_RESERVED4 127
#define SLL_ASSEMBLY_INSTRUCTION_FLAG_ANONYMOUS 128
#define SLL_ASSEMBLY_INSTRUCTION_FLAG_INPLACE 128
#define SLL_ASSEMBLY_INSTRUCTION_FLAG_RELATIVE 128
#define SLL_ASSEMBLY_INSTRUCTION_GET_TYPE(instruction) ((instruction)->type&0x7f)
#define SLL_ASSEMBLY_INSTRUCTION_FLAG_IS_ANONYMOUS(instruction) ((instruction)->type>>7)
#define SLL_ASSEMBLY_INSTRUCTION_FLAG_IS_INPLACE(instruction) ((instruction)->type>>7)
#define SLL_ASSEMBLY_INSTRUCTION_FLAG_IS_RELATIVE(instruction) ((instruction)->type>>7)
#define SLL_INIT_ASSEMBLY_DATA_STRUCT {0,NULL,0,0,0,{NULL,0},{NULL,0},{NULL,0},{NULL,NULL,NULL,0}}
#define SLL_ASSEMBLY_FUNCTION_GET_ARGUMENT_COUNT(function) ((function)->arg_count>>1)
#define SLL_ASSEMBLY_FUNCTION_IS_VAR_ARG(function) ((function)->arg_count&1)
#define SLL_ASSEMBLY_VARIABLE_GET_INDEX(variable) ((variable)>>1)
#define SLL_ASSEMBLY_VARIABLE_IS_TLS(variable) ((variable)&1)
#define SLL_MAX_BARRIER_INDEX __SLL_U32_MAX
#define SLL_MAX_MAP_LENGTH __SLL_U32_MAX
#define SLL_INIT_MAP(out)do{(out)->length=0;(out)->data=NULL;} while (0)
#define SLL_INIT_MAP_STRUCT {0,NULL}
#define SLL_MAX_ARG_COUNT __SLL_U32_MAX
#define SLL_MAX_SIZE __SLL_U64_MAX
#define SLL_COMPARE_RESULT_BELOW 0
#define SLL_COMPARE_RESULT_EQUAL 1
#define SLL_COMPARE_RESULT_ABOVE 2
#define SLL_COPY_STRING_NULL(source,target) (*((sll_char_t*)sll_copy_string((source),(target)))=0)
#define SLL_CONTAINER_CLEAR(c)do{sll_container_t* __c=(c);sll_allocator_release(__c->data);__c->data=NULL;__c->size=0;} while (0)
#define SLL_CONTAINER_FILTER(c,type,var,check,delete)do{sll_container_t* __c=(c);sll_size_t __i=0;type* __ptr=(type*)(__c->data);for (sll_size_t __j=0;__j<__c->size;__j++){type var=*(__ptr+__j);if (!(check)){delete;}else{*(__ptr+__i)=*(__ptr+__j);__i++;}}if (__i!=__c->size){__c->size=__i;sll_allocator_resize(&(__c->data),__i*sizeof(type));}} while (0)
#define SLL_CONTAINER_INIT(c)do{sll_container_t* __c=(c);__c->data=NULL;__c->size=0;} while (0)
#define SLL_CONTAINER_INIT_STRUCT {NULL,0}
#define SLL_CONTAINER_ITER(c,type,var,code)do{sll_container_t* __c=(c);type* __ptr=(type*)(__c->data);for (sll_size_t __i=0;__i<__c->size;__i++){type var=*(__ptr+__i);code;}} while (0)
#define SLL_CONTAINER_ITER_CLEAR(c,type,var,code)do{sll_container_t* __c_tmp=(c);SLL_CONTAINER_ITER(__c_tmp,type,var,code);SLL_CONTAINER_CLEAR(__c_tmp);} while (0)
#define SLL_CONTAINER_PUSH(c,type,elem)do{sll_container_t* __c=(c);__c->size++;sll_allocator_resize(&(__c->data),__c->size*sizeof(type));*(((type*)(__c->data))+__c->size-1)=(elem);} while (0)
#define SLL_HANDLE_CONTAINER_ALLOC(c,idx)do{sll_handle_container_t* __c=(c);sll_size_t* __idx=(idx);if (__c->index!=0xffffffffffffffffull){sll_size_t __i=__c->index&0x7fffffffffffffffull;__c->index=(sll_size_t)(*(__c->data+__i));*__idx=__i;}else{*__idx=__c->size;__c->size++;sll_allocator_resize((void**)(&(__c->data)),__c->size*sizeof(void*));}} while (0)
#define SLL_HANDLE_CONTAINER_CHECK(c,index) ((index)<(c)->size&&!(((sll_size_t)(*((c)->data+(index))))>>63))
#define SLL_HANDLE_CONTAINER_CLEAR(c)do{sll_handle_container_t* __c=(c);sll_allocator_release(__c->data);__c->data=NULL;__c->size=0;__c->index=0xffffffffffffffffull;} while (0)
#define SLL_HANDLE_CONTAINER_DEALLOC(c,idx)do{sll_handle_container_t* __c=(c);sll_size_t __i=(idx);*(__c->data+__i)=(void*)(__c->index|0x8000000000000000ull);__c->index=__i;} while (0)
#define SLL_HANDLE_CONTAINER_GET(c,index) ((index)<(c)->size&&!(((sll_size_t)(*((c)->data+(index))))>>63)?*((c)->data+(index)):NULL)
#define SLL_HANDLE_CONTAINER_INIT(c)do{sll_handle_container_t* __c=(c);__c->data=NULL;__c->size=0;__c->index=0xffffffffffffffffull;} while (0)
#define SLL_HANDLE_CONTAINER_INIT_STRUCT {NULL,0,0xffffffffffffffffull}
#define SLL_HANDLE_CONTAINER_ITER(c,type,var,code)do{sll_handle_container_t* __c=(c);for (sll_size_t __i=0;__i<__c->size;__i++){type* var=(type*)(*(__c->data+__i));if (((sll_size_t)var)>>63){continue;}code;}} while (0)
#define SLL_HANDLE_CONTAINER_ITER_CLEAR(c,type,var,code)do{sll_handle_container_t* __c_tmp=(c);SLL_HANDLE_CONTAINER_ITER(__c_tmp,type,var,code);SLL_HANDLE_CONTAINER_CLEAR(__c_tmp);} while (0)
#define SLL_MAX_LOCK_INDEX __SLL_U32_MAX
#define SLL_MAX_FILE_OFFSET __SLL_U64_MAX
#define SLL_FILE_FLAG_READ 1
#define SLL_FILE_FLAG_WRITE 2
#define SLL_FILE_FLAG_APPEND 4
#define SLL_FILE_FLAG_NO_BUFFER 8
#define SLL_FILE_FLUSH_ON_NEWLINE 16
#define SLL_FILE_FLAG_ASYNC 32
#define SLL_FILE_FLAG_SOCKET 64
#define SLL_FILE_FLAG_RESERVED0 128
#define SLL_FILE_FLAG_RESERVED1 256
#define SLL_FILE_FLAG_RESERVED2 512
#define SLL_FILE_GET_LINE_NUMBER(file) ((file)->_line_number)
#define SLL_FILE_GET_OFFSET(file) ((file)->_offset)
#define SLL_END_OF_DATA __SLL_U16_MAX
#define SLL_MAX_TIME __SLL_U64_MAX
#define SLL_PLATFORM_STREAM_INPUT 0
#define SLL_PLATFORM_STREAM_OUTPUT 1
#define SLL_PLATFORM_STREAM_ERROR 2
#define SLL_NO_FILE_SIZE 0xffffffffffffffffull
#define SLL_UNKNOWN_FILE_DESCRIPTOR ((sll_file_descriptor_t)0xffffffffffffffffull)
#define SLL_CPU_ANY 0xffff
#define SLL_UNKNOWN_INTERNAL_THREAD_INDEX ((void*)0xffffffffffffffffull)
#define SLL_RANDOM_BITS(x) sll_platform_random(&(x),sizeof(x))
#define SLL_PAGE_SIZE 4096
#define SLL_LARGE_PAGE_SIZE 2097152
#define SLL_ROUND_PAGE(size) (((size)+SLL_PAGE_SIZE-1)&(-SLL_PAGE_SIZE))
#define SLL_ROUND_LARGE_PAGE(size) (((size)+SLL_LARGE_PAGE_SIZE-1)&(-SLL_LARGE_PAGE_SIZE))
#define SLL_SEARCH_PATH_SPLIT_CHAR ':'
#define SLL_SEARCH_PATH_FLAG_BEFORE 1
#define SLL_SEARCH_PATH_FLAG_AFTER 2
#define SLL_OBJECT_REFERENCE_COUNTER_MASK 0xffffffffffffull
#define SLL_GET_OBJECT_REFERENCE_COUNTER(o) ((o)->rc&SLL_OBJECT_REFERENCE_COUNTER_MASK)
#define SLL_ACQUIRE(object) ((object)->rc++)
#define SLL_RELEASE(object)do{sll_object_t* __o=(object);__o->rc--;if (!SLL_GET_OBJECT_REFERENCE_COUNTER(__o)){sll__release_object_internal(__o);}} while (0)
#define SLL_NODE_TYPE_INT 0
#define SLL_NODE_TYPE_FLOAT 1
#define SLL_NODE_TYPE_CHAR 2
#define SLL_NODE_TYPE_COMPLEX 3
#define SLL_NODE_TYPE_STRING 4
#define SLL_NODE_TYPE_ARRAY 5
#define SLL_NODE_TYPE_MAP 6
#define SLL_NODE_TYPE_IDENTIFIER 7
#define SLL_NODE_TYPE_FIELD 8
#define SLL_NODE_TYPE_FUNCTION_ID 9
#define SLL_NODE_TYPE_PRINT 10
#define SLL_NODE_TYPE_AND 11
#define SLL_NODE_TYPE_OR 12
#define SLL_NODE_TYPE_NOT 13
#define SLL_NODE_TYPE_BOOL 14
#define SLL_NODE_TYPE_ASSIGN 15
#define SLL_NODE_TYPE_FUNC 16
#define SLL_NODE_TYPE_INTERNAL_FUNC 17
#define SLL_NODE_TYPE_INTERNAL_FUNC_LOAD 18
#define SLL_NODE_TYPE_INLINE_FUNC 19
#define SLL_NODE_TYPE_CALL 20
#define SLL_NODE_TYPE_CALL_ARRAY 21
#define SLL_NODE_TYPE_IF 22
#define SLL_NODE_TYPE_INLINE_IF 23
#define SLL_NODE_TYPE_SWITCH 24
#define SLL_NODE_TYPE_FOR 25
#define SLL_NODE_TYPE_WHILE 26
#define SLL_NODE_TYPE_LOOP 27
#define SLL_NODE_TYPE_INC 28
#define SLL_NODE_TYPE_DEC 29
#define SLL_NODE_TYPE_ADD 30
#define SLL_NODE_TYPE_SUB 31
#define SLL_NODE_TYPE_MULT 32
#define SLL_NODE_TYPE_DIV 33
#define SLL_NODE_TYPE_FLOOR_DIV 34
#define SLL_NODE_TYPE_MOD 35
#define SLL_NODE_TYPE_BIT_AND 36
#define SLL_NODE_TYPE_BIT_OR 37
#define SLL_NODE_TYPE_BIT_XOR 38
#define SLL_NODE_TYPE_BIT_NOT 39
#define SLL_NODE_TYPE_BIT_RIGHT_SHIFT 40
#define SLL_NODE_TYPE_BIT_LEFT_SHIFT 41
#define SLL_NODE_TYPE_LESS 42
#define SLL_NODE_TYPE_LESS_EQUAL 43
#define SLL_NODE_TYPE_EQUAL 44
#define SLL_NODE_TYPE_NOT_EQUAL 45
#define SLL_NODE_TYPE_MORE 46
#define SLL_NODE_TYPE_MORE_EQUAL 47
#define SLL_NODE_TYPE_STRICT_EQUAL 48
#define SLL_NODE_TYPE_STRICT_NOT_EQUAL 49
#define SLL_NODE_TYPE_LENGTH 50
#define SLL_NODE_TYPE_ACCESS 51
#define SLL_NODE_TYPE_DEEP_COPY 52
#define SLL_NODE_TYPE_VAR_ACCESS 53
#define SLL_NODE_TYPE_HAS 54
#define SLL_NODE_TYPE_CAST 55
#define SLL_NODE_TYPE_TYPEOF 56
#define SLL_NODE_TYPE_NAMEOF 57
#define SLL_NODE_TYPE_NAMEOF_TYPE 58
#define SLL_NODE_TYPE_DECL 59
#define SLL_NODE_TYPE_NEW 60
#define SLL_NODE_TYPE_FOR_ARRAY 61
#define SLL_NODE_TYPE_WHILE_ARRAY 62
#define SLL_NODE_TYPE_FOR_MAP 63
#define SLL_NODE_TYPE_WHILE_MAP 64
#define SLL_NODE_TYPE_BREAK 65
#define SLL_NODE_TYPE_CONTINUE 66
#define SLL_NODE_TYPE_REF 67
#define SLL_NODE_TYPE_RETURN 68
#define SLL_NODE_TYPE_COMMA 69
#define SLL_NODE_TYPE_OPERATION_LIST 70
#define SLL_NODE_TYPE_THREAD_ID 71
#define SLL_NODE_TYPE_THREAD_WAIT 72
#define SLL_NODE_TYPE_THREAD_LOCK 73
#define SLL_NODE_TYPE_THREAD_SEMAPHORE 74
#define SLL_NODE_TYPE_THREAD_BARRIER_EQ 75
#define SLL_NODE_TYPE_THREAD_BARRIER_GEQ 76
#define SLL_NODE_TYPE_THREAD_EXIT 77
#define SLL_NODE_TYPE_READ_BLOCKING 78
#define SLL_NODE_TYPE_READ_BLOCKING_CHAR 79
#define SLL_NODE_TYPE_DBG 80
#define SLL_NODE_TYPE_CHANGE_STACK 81
#define SLL_NODE_TYPE_RESERVED0 254
#define SLL_NODE_TYPE_NOP 255
#define SLL_IS_OBJECT_TYPE_NOT_TYPE(node) ((node)->type>SLL_NODE_TYPE_FUNCTION_ID)
#define SLL_IS_OBJECT_TYPE_IF(node) ((node)->type>=SLL_NODE_TYPE_IF&&(node)->type<=SLL_NODE_TYPE_SWITCH)
#define SLL_INIT_COMPILATION_DATA_STRUCT {NULL,0}
#define SLL_FUNCTION_GET_ARGUMENT_COUNT(function) ((function)->arg_count>>1)
#define SLL_FUNCTION_GET_ARGUMENT_COUNT_RAW(arg_count) ((arg_count)>>1)
#define SLL_FUNCTION_IS_VAR_ARG(function) ((function)->arg_count&1)
#define SLL_MAX_SCOPE __SLL_U32_MAX
#define SLL_MAX_IDENTIFIER_INDEX __SLL_U32_MAX
#define SLL_MAX_IDENTIFIER_LIST_LENGTH __SLL_U32_MAX
#define SLL_IDENTIFIER_GET_ARRAY_ID(identifier_index) ((identifier_index)&0xf)
#define SLL_IDENTIFIER_GET_ARRAY_INDEX(identifier_index) ((identifier_index)>>4)
#define SLL_IDENTIFIER_ADD_INDEX(identifier_index,delta_index) ((identifier_index)+((delta_index)<<4))
#define SLL_CREATE_IDENTIFIER(index,id) (((index)<<4)|(id))
#define SLL_IDENTIFIER_GET_STRING_INDEX(identifier) ((identifier)->name_string_index>>1)
#define SLL_IDENTIFIER_IS_TLS(identifier) ((identifier)->name_string_index&1)
#define SLL_IDENTIFIER_UPDATE_STRING_INDEX(identifier,name_string_index_) ((identifier)->name_string_index=((name_string_index_)<<1)|((identifier)->name_string_index&1))
#define SLL_IDENTIFIER_SET_STRING_INDEX(identifier,name_string_index_,tls) ((identifier)->name_string_index=((name_string_index_)<<1)|(!!(tls)))
#define SLL_CLI_FLAG_EXPAND_PATH 1
#define SLL_CLI_FLAG_GENERATE_ASSEMBLY 2
#define SLL_CLI_FLAG_GENERATE_BUNDLE 4
#define SLL_CLI_FLAG_GENERATE_COMPILED_OBJECT 8
#define SLL_CLI_FLAG_HELP 16
#define SLL_CLI_FLAG_NO_PATHS 32
#define SLL_CLI_FLAG_NO_RUN 64
#define SLL_CLI_FLAG_OPTIMIZE 128
#define SLL_CLI_FLAG_PRINT_ASSEMBLY 256
#define SLL_CLI_FLAG_PRINT_NODES 512
#define SLL_CLI_FLAG_RELEASE_MODE 1024
#define SLL_CLI_FLAG_STRIP_DEBUG 2048
#define SLL_CLI_FLAG_STRIP_NAMES 4096
#define SLL_CLI_FLAG_VERBOSE 8192
#define SLL_CLI_FLAG_VERSION 16384
#define SLL_CLI_FLAG_ENABLE_ERRORS 32768
#define SLL_CLI_FLAG_RESERVED0 65536
#define SLL_LOOKUP_RESULT_COMPILED_OBJECT 0
#define SLL_LOOKUP_RESULT_ASSEMBLY 1
#define SLL_LOOKUP_RESULT_EMPTY 2
#define SLL_MAX_THREAD_INDEX 0xfffffffe
#define SLL_UNKNOWN_THREAD_INDEX 0xffffffff
#define SLL_MAX_STRING_INDEX __SLL_U32_MAX
#define SLL_LOG(format,...) sll_log(SLL_CHAR(__FILE__),SLL_CHAR(__func__),__LINE__,0,SLL_CHAR(format),##__VA_ARGS__)
#define SLL_WARN(format,...) sll_log(SLL_CHAR(__FILE__),SLL_CHAR(__func__),__LINE__,1,SLL_CHAR(format),##__VA_ARGS__)
#define SLL_LOG_FLAG_SHOW 1
#define SLL_LOG_FLAG_NO_HEADER 2
#define SLL_PARSE_ARGS_TYPE_INT 0
#define SLL_PARSE_ARGS_TYPE_FLOAT 1
#define SLL_PARSE_ARGS_TYPE_COMPLEX 2
#define SLL_PARSE_ARGS_TYPE_CHAR 0
#define SLL_PARSE_ARGS_TYPE_STRING 1
#define SLL_MAX_ARRAY_LENGTH __SLL_U32_MAX
#define SLL_INIT_ARRAY(out)do{(out)->length=0;(out)->data=NULL;} while (0)
#define SLL_INIT_ARRAY_STRUCT {0,NULL}
#define SLL_OFFSETOF(type,field) ((sll_size_t)(&(((type*)NULL)->field)))
#define SLL_API_FILE_PATH_SEPARATOR '/'
#define SLL_API_MAX_FILE_PATH_LENGTH 4096
#define SLL_DECODE_SIGNED_INTEGER(v) (((v)>>1)^(-((sll_integer_t)((v)&1))))
#define SLL_ENCODE_SIGNED_INTEGER(v) ((((v)<0?~(v):(v))<<1)|((v)<0))
#define SLL_MAX_JSON_ARRAY_LENGTH __SLL_U32_MAX
#define SLL_MAX_JSON_MAP_LENGTH __SLL_U32_MAX
#define SLL_JSON_OBJECT_TYPE_NULL 0
#define SLL_JSON_OBJECT_TYPE_FALSE 1
#define SLL_JSON_OBJECT_TYPE_TRUE 2
#define SLL_JSON_OBJECT_TYPE_INTEGER 3
#define SLL_JSON_OBJECT_TYPE_FLOAT 4
#define SLL_JSON_OBJECT_TYPE_STRING 5
#define SLL_JSON_OBJECT_TYPE_ARRAY 6
#define SLL_JSON_OBJECT_TYPE_MAP 7
#define SLL_PROCESS_FLAG_PASS_STDIN 1
#define SLL_PROCESS_FLAG_CAPTURE_STDOUT 2
#define SLL_PROCESS_FLAG_CAPTURE_STDERR 4
#define SLL_PROCESS_FLAG_WAIT 8
#define SLL_INIT_MD5(o)do{(o)->a=0x67452301;(o)->b=0xefcdab89;(o)->c=0x98badcfe;(o)->d=0x10325476;} while (0)
#define SLL_INIT_SHA1(o)do{(o)->a=0x67452301;(o)->b=0xefcdab89;(o)->c=0x98badcfe;(o)->d=0x10325476;(o)->e=0xc3d2e1f0;} while (0)
#define SLL_INIT_SHA256(o)do{(o)->a=0x6a09e667;(o)->b=0xbb67ae85;(o)->c=0x3c6ef372;(o)->d=0xa54ff53a;(o)->e=0x510e527f;(o)->f=0x9b05688c;(o)->g=0x1f83d9ab;(o)->h=0x5be0cd19;} while (0)
#define SLL_INIT_SHA512(o)do{(o)->a=0x6a09e667f3bcc908ull;(o)->b=0xbb67ae8584caa73bull;(o)->c=0x3c6ef372fe94f82bull;(o)->d=0xa54ff53a5f1d36f1ull;(o)->e=0x510e527fade682d1ull;(o)->f=0x9b05688c2b3e6c1full;(o)->g=0x1f83d9abfb41bd6bull;(o)->h=0x5be0cd19137e2179ull;} while (0)
#define SLL_INIT_MD5_STRUCT {0x67452301,0xefcdab89,0x98badcfe,0x10325476}
#define SLL_INIT_SHA1_STRUCT {0x67452301,0xefcdab89,0x98badcfe,0x10325476,0xc3d2e1f0}
#define SLL_INIT_SHA256_STRUCT {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19}
#define SLL_INIT_SHA512_STRUCT {0x6a09e667f3bcc908ull,0xbb67ae8584caa73bull,0x3c6ef372fe94f82bull,0xa54ff53a5f1d36f1ull,0x510e527fade682d1ull,0x9b05688c2b3e6c1full,0x1f83d9abfb41bd6bull,0x5be0cd19137e2179ull}
#define SLL_MEMORY_MOVE_DIRECTION_FROM_STACK 0
#define SLL_MEMORY_MOVE_DIRECTION_TO_STACK 1
#define SLL_OBJECT_TYPE_INT 0
#define SLL_OBJECT_TYPE_FLOAT 1
#define SLL_OBJECT_TYPE_CHAR 2
#define SLL_OBJECT_TYPE_COMPLEX 3
#define SLL_OBJECT_TYPE_STRING 4
#define SLL_OBJECT_TYPE_ARRAY 5
#define SLL_OBJECT_TYPE_MAP 6
#define SLL_OBJECT_TYPE_MAP_KEYS 7
#define SLL_OBJECT_TYPE_MAP_VALUES 8
#define SLL_OBJECT_TYPE_OBJECT 0xffffffff
#define SLL_MAX_OBJECT_TYPE SLL_OBJECT_TYPE_MAP_VALUES
#define SLL_INIT_OBJECT_TYPE_TABLE(out)do{(out)->dt=NULL;(out)->l=0;} while (0)
#define SLL_INIT_OBJECT_TYPE_TABLE_STRUCT {NULL,0}
#define SLL_DEBUG_LINE_DATA_FLAG_FILE 1ull
#define SLL_DEBUG_LINE_DATA_FLAG_FUNC 2ull
#define SLL_DEBUG_LINE_DATA_GET_DATA(debug_data) ((debug_data)->line>>2)
#define SLL_DEBUG_LINE_DATA_SET_DATA(debug_data,index,flags) (debug_data)->line=((index)<<2)|(flags)
#define SLL_ABI_AUDIT_CALL __sll_audit
#define SLL_ABI_AUDIT_DEINIT __sll_audit_deinit
#define SLL_ABI_AUDIT_INIT __sll_audit_init
#define SLL_ABI_DEINIT __sll_deinit
#define SLL_ABI_INIT __sll_init
#define SLL_ABI_INTERNAL_FUNCTION_TABLE_DESCRIPTOR __sll_ift
#define SLL_ABI_PATH_RESOLVER_DEINIT __sll_path_resolver_deinit
#define SLL_ABI_PATH_RESOLVER_INIT __sll_path_resolver_init
#define SLL_ABI_PATH_RESOLVER_RESOLVE __sll_path_resolver
#define SLL_ABI_NAME(x) SLL_CHAR(_SLL_ABI_NAME(x))
#define SLL_EXECUTE_FUNCTION_ASYNC 1
#define SLL_EXECUTE_FUNCTION_RESERVED0 2
#define SLL_ACQUIRE_STATIC(name) (SLL_ACQUIRE(sll_static_##name),sll_static_##name)
#define SLL_ACQUIRE_STATIC_INT(value) (SLL_ACQUIRE(sll_static_int[(value)]),sll_static_int[(value)])
#define SLL_ACQUIRE_STATIC_NEG_INT(value) (SLL_ACQUIRE(sll_static_negative_int[(value)-1]),sll_static_negative_int[(value)-1])
#define SLL_FROM_CHAR(char_) (SLL_ACQUIRE(sll_static_char[(sll_char_t)(char_)]),sll_static_char[(sll_char_t)(char_)])
#define SLL_CLEANUP_TYPE_GLOBAL 0
#define SLL_CLEANUP_TYPE_VM 1
#define SLL_MAX_FUNCTION_INDEX 0xfffffffe
#define SLL_UNKNOWN_INTERNAL_FUNCTION_INDEX 0xffffffff
#define SLL_SANDBOX_FLAG_DISABLE_FILE_IO 0
#define SLL_SANDBOX_FLAG_ENABLE_STDIN_IO 1
#define SLL_SANDBOX_FLAG_ENABLE_STDOUT_IO 2
#define SLL_SANDBOX_FLAG_DISABLE_PATH_API 3
#define SLL_SANDBOX_FLAG_DISABLE_PROCESS_API 4
#define SLL_SANDBOX_FLAG_DISABLE_ENVIRONMENT 5
#define SLL_SANDBOX_FLAG_DISABLE_LOAD_LIBRARY 6
#define SLL_SANDBOX_FLAG_ENABLE_BUFFER_FILES 7
#define SLL_SANDBOX_FLAG_ENABLE_FILE_RENAME 8
#define SLL_SANDBOX_FLAG_ENABLE_FILE_COPY 9
#define SLL_SANDBOX_FLAG_DISABLE_FLOAT_COMPARE_ERROR_CHANGE 10
#define SLL_SANDBOX_FLAG_ENABLE_FILE_DELETE 11
#define SLL_SANDBOX_FLAG_DISABLE_THREADS 12
#define SLL_SANDBOX_FLAG_DISABLE_RANDOM 13
#define SLL_SANDBOX_FLAG_DISABLE_SERIAL 14
#define SLL_SANDBOX_FLAG_DISABLE_REFERENCE_COUNTER 15
#define SLL_MAX_SANDBOX_FLAG SLL_SANDBOX_FLAG_DISABLE_REFERENCE_COUNTER
#define SLL_INIT_COMPLEX(out)do{(out)->real=0;(out)->imag=0;} while (0)
#define SLL_INIT_COMPLEX_STRUCT {0,0}
#define SLL_MAX_CHAR __SLL_U8_MAX
#define SLL_MAX_STRING_LENGTH __SLL_U32_MAX
#define SLL_CHAR(pointer) ((sll_char_t*)(pointer))
#define SLL_INIT_STRING(out)do{(out)->length=0;(out)->checksum=0;(out)->data=NULL;} while (0)
#define SLL_INIT_STRING_STRUCT {0,0,NULL}
#define SLL_STRING_ALIGN_LENGTH(length) (((length)+8)&0xfffffffffffffff8ull)
#define SLL_STRING_COMBINE_CHECKSUMS(a,length,b) (((sll_string_checksum_t)(a))^((((sll_string_checksum_t)(b))<<(((length)&3)<<3))|(((sll_string_checksum_t)(b))>>(32-(((length)&3)<<3)))))
#define SLL_STRING_ESCAPE(char_) ((char_)=='\t'||(char_)=='\n'||(char_)=='\v'||(char_)=='\f'||(char_)=='\r'||(char_)=='\"'||(char_)=='\''||(char_)=='\\')
#define SLL_STRING_FORMAT_PADDING(pointer,length)do{(*((__SLL_U64*)((pointer)+((length)&0xfffffffffffffff8ull))))&=(1ull<<(((length)&7)<<3))-1;} while (0)
#define SLL_STRING_HEX_ESCAPE(char_) ((char_)<32||(char_)>126)
#define SLL_STRING_INSERT_POINTER_STATIC(static_string,index,string) sll_string_insert_pointer_length(SLL_CHAR(static_string),sizeof(static_string)/sizeof(char)-1,(index),(string))
#define SLL_INVALID_CHARACTER 0xffffffff
struct _SLL_OBJECT;
struct _SLL_JSON_OBJECT;
struct _SLL_JSON_MAP_KEYPAIR;
typedef unsigned char sll_char_t;
typedef unsigned int sll_string_checksum_t;
typedef unsigned int sll_string_length_t;
typedef unsigned int sll_wide_char_t;
typedef struct _SLL_STRING{sll_string_length_t length;sll_string_checksum_t checksum;sll_char_t* data;} sll_string_t;
typedef unsigned int sll_semaphore_counter_t;
typedef unsigned int sll_semaphore_index_t;
typedef unsigned long long int sll_error_t;
typedef unsigned int sll_array_length_t;
typedef struct _SLL_ARRAY{sll_array_length_t length;struct _SLL_OBJECT** data;} sll_array_t;
typedef void (*sll_audit_callback_t)(const sll_string_t* name,const sll_array_t* args);
typedef unsigned char sll_var_arg_list_type_t;
typedef unsigned long long int sll_reference_count_t;
typedef unsigned int sll_object_type_t;
typedef signed long long int sll_integer_t;
typedef double sll_float_t;
typedef struct _SLL_COMPLEX{sll_float_t real;sll_float_t imag;} sll_complex_t;
typedef unsigned int sll_map_length_t;
typedef struct _SLL_MAP{sll_map_length_t length;struct _SLL_OBJECT** data;} sll_map_t;
typedef union _SLL_OBJECT_FIELD{sll_integer_t int_;sll_float_t float_;sll_char_t char_;struct _SLL_OBJECT* any;} sll_object_field_t;
typedef struct _SLL_OBJECT_PTR{struct _SLL_OBJECT* prev;struct _SLL_OBJECT* next;} sll_object_ptr_t;
typedef union _SLL_OBJECT_DATA{sll_integer_t int_;sll_float_t float_;sll_char_t char_;sll_complex_t complex_;sll_string_t string;sll_array_t array;sll_map_t map;sll_object_field_t* fields;sll_object_ptr_t _next_object;sll_array_length_t _pool_index;} sll_object_data_t;
typedef struct _SLL_OBJECT{sll_reference_count_t rc;const sll_object_type_t type;unsigned int _flags;unsigned long long int _data;sll_object_data_t data;} sll_object_t;
typedef unsigned int sll_arg_count_t;
typedef struct _SLL_VAR_ARG_LIST_DATA_SLL{sll_object_t*const* pointer;sll_arg_count_t count;} sll_var_arg_list_data_sll_t;
typedef unsigned long long int sll_size_t;
typedef struct _SLL_VAR_ARG_LIST_DATA_STRUCT{const void* base_pointer;sll_size_t* offset_data;sll_arg_count_t offset_count;void** converter_function_data;sll_arg_count_t converter_function_count;} sll_var_arg_list_data_struct_t;
typedef union _SLL_VAR_ARG_LIST_DATA{va_list* c;sll_var_arg_list_data_sll_t sll;sll_var_arg_list_data_struct_t struct_;} sll_var_arg_list_data_t;
typedef struct _SLL_VAR_ARG_LIST{sll_var_arg_list_type_t type;sll_var_arg_list_data_t data;} sll_var_arg_list_t;
typedef unsigned int sll_version_t;
typedef unsigned int sll_tls_object_length_t;
typedef unsigned int sll_thread_index_t;
typedef struct _SLL_TLS_VALUE{sll_thread_index_t thread_index;sll_object_t* value;} sll_tls_value_t;
typedef struct _SLL_TLS_OBJECT{sll_tls_object_length_t length;sll_tls_value_t* data;} sll_tls_object_t;
typedef unsigned char sll_assembly_instruction_type_t;
typedef signed int sll_relative_instruction_index_t;
typedef unsigned int sll_debug_data_length_t;
typedef unsigned int sll_instruction_index_t;
typedef unsigned int sll_variable_index_t;
typedef union _SLL_ASSEMBLY_INSTRUCTION_DATA_JUMP_TARGET{sll_instruction_index_t abs;sll_relative_instruction_index_t rel;} sll_assembly_instruction_data_jump_target_t;
typedef struct _SLL_ASSEMBLY_INSTRUCTION_DATA_JUMP{sll_assembly_instruction_data_jump_target_t target;void* _instruction;} sll_assembly_instruction_data_jump_t;
typedef struct _SLL_ASSEMBLY_INSTRUCTION_DATA_VAR_ACCESS{sll_variable_index_t variable;sll_arg_count_t arg_count;} sll_assembly_instruction_data_var_access_t;
typedef unsigned long long int sll_compressed_integer_t;
typedef unsigned int sll_string_index_t;
typedef unsigned int sll_stack_offset_t;
typedef union _SLL_ASSEMBLY_INSTRUCTION_DATA{sll_integer_t int_;sll_compressed_integer_t compressed_int;sll_float_t float_;sll_char_t char_;sll_complex_t complex_;sll_string_index_t string_index;sll_variable_index_t variable;sll_assembly_instruction_data_jump_t jump;sll_arg_count_t arg_count;sll_array_length_t array_length;sll_map_length_t map_length;sll_object_type_t type;sll_assembly_instruction_data_var_access_t variable_access;sll_stack_offset_t stack_offset;void* _next_instruction;} sll_assembly_instruction_data_t;
typedef struct _SLL_ASSEMBLY_INSTRUCTION{sll_assembly_instruction_type_t type;sll_assembly_instruction_data_t data;} sll_assembly_instruction_t;
typedef struct _SLL_ASSEMBLY_FUNCTION{sll_instruction_index_t instruction_index;sll_arg_count_t arg_count;} sll_assembly_function_t;
typedef unsigned int sll_function_index_t;
typedef struct _SLL_ASSEMBLY_FUNCTION_TABLE{sll_assembly_function_t* data;sll_function_index_t length;} sll_assembly_function_table_t;
typedef unsigned long long int sll_file_offset_t;
typedef struct _SLL_DEBUG_LINE_DATA{sll_instruction_index_t delta_instruction_index;sll_file_offset_t line;} sll_debug_line_data_t;
typedef struct _SLL_DEBUG_DATA{sll_debug_line_data_t* data;sll_debug_data_length_t length;} sll_debug_data_t;
typedef struct _SLL_ASSEMBLY_STACK_DATA{void* start;void* end;sll_assembly_instruction_t* next_instruction;sll_size_t count;} sll_assembly_stack_data_t;
typedef unsigned long long int sll_time_t;
typedef struct _SLL_STRING_TABLE{sll_string_t* data;sll_string_index_t length;} sll_string_table_t;
typedef struct _SLL_ASSEMBLY_DATA{sll_time_t time;sll_assembly_instruction_t* first_instruction;sll_instruction_index_t instruction_count;sll_variable_index_t variable_count;sll_variable_index_t tls_variable_count;sll_assembly_function_table_t function_table;sll_string_table_t string_table;sll_debug_data_t debug_data;sll_assembly_stack_data_t _instruction_stack;} sll_assembly_data_t;
typedef unsigned int sll_barrier_counter_t;
typedef unsigned int sll_barrier_index_t;
typedef _Bool sll_bool_t;
typedef sll_object_t* (*sll_binary_operator_t)(sll_object_t* a,sll_object_t* b);
typedef unsigned char sll_compare_result_t;
typedef struct _SLL_CONTAINER{void* data;sll_size_t size;} sll_container_t;
typedef struct _SLL_HANDLE_CONTAINER{void** data;sll_size_t size;sll_size_t index;} sll_handle_container_t;
typedef void (*sll_container_callback_t)(void* elem);
typedef sll_bool_t (*sll_container_check_callback_t)(void* elem);
typedef struct _SLL_SHA256_DATA{unsigned int a;unsigned int b;unsigned int c;unsigned int d;unsigned int e;unsigned int f;unsigned int g;unsigned int h;} sll_sha256_data_t;
typedef unsigned char sll_node_type_t;
typedef unsigned int sll_identifier_index_t;
typedef unsigned int sll_scope_t;
typedef struct _SLL_FUNCTION_NODE_DATA{sll_arg_count_t arg_count;sll_function_index_t function_index;sll_scope_t scope;} sll_function_node_data_t;
typedef struct _SLL_LOOP_NODE_DATA{sll_arg_count_t arg_count;sll_scope_t scope;} sll_loop_node_data_t;
typedef struct _SLL_DECL_NODE_DATA{sll_arg_count_t arg_count;sll_string_index_t name_string_index;} sll_decl_node_data_t;
typedef union _SLL_NODE_DATA{sll_integer_t int_;sll_float_t float_;sll_char_t char_;sll_complex_t complex_;sll_string_index_t string_index;sll_array_length_t array_length;sll_map_length_t map_length;sll_identifier_index_t identifier_index;sll_function_node_data_t function;sll_loop_node_data_t loop;sll_decl_node_data_t declaration;sll_arg_count_t arg_count;sll_function_index_t function_index;void* _next_node;} sll_node_data_t;
typedef struct _SLL_NODE{sll_node_type_t type;sll_node_data_t data;} sll_node_t;
typedef struct _SLL_IDENTIFIER{sll_scope_t scope;sll_string_index_t name_string_index;} sll_identifier_t;
typedef unsigned int sll_identifier_list_length_t;
typedef struct _SLL_IDENTIFIER_LIST{sll_identifier_t* data;sll_identifier_list_length_t length;} sll_identifier_list_t;
typedef struct _SLL_IDENTIFIER_TABLE{sll_identifier_list_t short_[SLL_MAX_SHORT_IDENTIFIER_LENGTH];sll_identifier_t* long_data;sll_identifier_list_length_t long_data_length;} sll_identifier_table_t;
typedef unsigned int sll_export_table_length_t;
typedef struct _SLL_EXPORT_TABLE{sll_identifier_index_t* data;sll_export_table_length_t length;} sll_export_table_t;
typedef unsigned int sll_node_offset_t;
typedef struct _SLL_FUNCTION{sll_node_offset_t offset;sll_string_index_t name_string_index;sll_string_index_t description_string_index;sll_arg_count_t arg_count;sll_identifier_index_t args[];} sll_function_t;
typedef struct _SLL_FUNCTION_TABLE{sll_function_t** data;sll_function_index_t length;} sll_function_table_t;
typedef unsigned int sll_source_file_index_t;
typedef struct _SLL_IMPORT_FILE{sll_source_file_index_t source_file_index;sll_identifier_list_length_t length;sll_identifier_index_t data[];} sll_import_file_t;
typedef unsigned int sll_import_index_t;
typedef struct _SLL_IMPORT_TABLE{sll_import_file_t** data;sll_import_index_t length;} sll_import_table_t;
typedef struct _SLL_NODE_STACK{void* start;void* end;sll_node_t* next_node;sll_node_offset_t offset;sll_size_t count;} sll_node_stack_t;
typedef struct _SLL_SOURCE_FILE{sll_time_t time;sll_file_offset_t file_size;sll_sha256_data_t file_hash;sll_node_t* first_node;sll_identifier_table_t identifier_table;sll_export_table_t export_table;sll_function_table_t function_table;sll_string_table_t string_table;sll_import_table_t import_table;sll_string_index_t file_path_string_index;sll_node_stack_t _stack;sll_scope_t _next_scope;} sll_source_file_t;
typedef struct _SLL_BUNDLE_SOURCE_FILE{sll_string_t name;sll_source_file_t data;} sll_bundle_source_file_t;
typedef struct _SLL_BUNDLE{sll_time_t time;sll_string_t names;sll_bundle_source_file_t** data;sll_source_file_index_t length;} sll_bundle_t;
typedef unsigned int sll_lock_index_t;
typedef unsigned short int sll_file_flags_t;
typedef unsigned short int sll_read_char_t;
typedef void* sll_file_descriptor_t;
typedef struct _SLL_FILE_DATA_FILE{const sll_file_descriptor_t fd;const sll_string_t path;} sll_file_data_file_t;
typedef struct _SLL_FILE_DATA_MEMORY{const void* pointer;const sll_size_t size;} sll_file_data_memory_t;
typedef union _SLL_FILE_DATA{const sll_file_data_file_t file;const sll_file_data_memory_t memory;} sll_file_data_t;
typedef struct _SLL_FILE_WRITE_BUFFER_STATIC{sll_char_t* pointer;sll_file_offset_t offset;} sll_file_write_buffer_static_t;
typedef struct _SLL_FILE_WRITE_BUFFER_DYNAMIC{void* b;void* t;sll_file_offset_t sz;sll_file_offset_t off;} sll_file_write_buffer_dynamic_t;
typedef union _SLL_FILE_WRITE_BUFFER{sll_file_write_buffer_static_t static_;sll_file_write_buffer_dynamic_t dynamic;} sll_file_write_buffer_t;
typedef struct _SLL_FILE_HASH{sll_sha256_data_t hash;sll_char_t buffer[64];unsigned char buffer_offset;} sll_file_hash_t;
typedef void* sll_lock_handle_t;
typedef struct _SLL_FILE{const sll_file_data_t source;const sll_file_flags_t flags;sll_file_offset_t _line_number;sll_file_offset_t _offset;sll_char_t* _read_buffer;sll_file_offset_t _read_buffer_offset;sll_file_offset_t _read_buffer_size;sll_file_write_buffer_t _write_buffer;sll_file_hash_t _hash;sll_lock_handle_t _lock;} sll_file_t;
typedef void* sll_library_handle_t;
typedef void* sll_event_handle_t;
typedef unsigned short int sll_cpu_t;
typedef void* sll_internal_thread_index_t;
typedef void (*sll_internal_thread_function_t)(void* arg);
typedef signed int sll_return_code_t;
typedef unsigned int sll_pid_t;
typedef void* sll_process_handle_t;
typedef unsigned char sll_search_flags_t;
typedef unsigned int sll_search_path_length_t;
typedef struct _SLL_SEARCH_PATH{sll_string_t* data;sll_search_path_length_t length;} sll_search_path_t;
typedef struct _SLL_COMPILATION_DATA{sll_source_file_t** data;sll_source_file_index_t length;} sll_compilation_data_t;
typedef sll_bool_t (*sll_import_resolver_t)(const sll_string_t* path,sll_compilation_data_t* out);
typedef unsigned int sll_environment_length_t;
typedef struct _SLL_ENVIRONMENT_VARIABLE{const sll_string_t key;const sll_string_t value;} sll_environment_variable_t;
typedef struct _SLL_ENVIRONMENT{const sll_environment_variable_t*const* data;const sll_environment_length_t length;} sll_environment_t;
typedef unsigned char sll_cli_lookup_result_t;
typedef union _SLL_CLI_LOOKUP_DATA_RETURN{sll_assembly_data_t assembly_data;sll_compilation_data_t compilation_data;} sll_cli_lookup_data_return_t;
typedef struct _SLL_CLI_LOOKUP_DATA{sll_char_t path[SLL_API_MAX_FILE_PATH_LENGTH];sll_cli_lookup_data_return_t data;} sll_cli_lookup_data_t;
typedef sll_cli_lookup_result_t (*sll_cli_path_resolver_t)(const sll_string_t* path,sll_cli_lookup_data_t* out);
typedef unsigned char sll_optimization_round_count_t;
typedef unsigned char sll_logger_flags_t;
typedef unsigned char sll_number_type_t;
typedef void* sll_arg_state_t;
typedef union _SLL_NUMBER_DATA{sll_integer_t int_;sll_float_t float_;sll_complex_t complex_;} sll_number_data_t;
typedef struct _SLL_NUMBER{sll_number_type_t type;sll_number_data_t data;} sll_number_t;
typedef union _SLL_CHAR_STRING_DATA{sll_char_t char_;const sll_string_t* string;} sll_char_string_data_t;
typedef struct _SLL_CHAR_STRING{sll_bool_t type;sll_char_string_data_t data;} sll_char_string_t;
typedef unsigned int sll_file_handle_t;
typedef unsigned char sll_day_t;
typedef unsigned char sll_hour_t;
typedef unsigned char sll_minute_t;
typedef unsigned char sll_month_t;
typedef unsigned short int sll_year_t;
typedef double sll_second_t;
typedef struct _SLL_TIME_ZONE{sll_char_t name[32];sll_time_t offset;} sll_time_zone_t;
typedef struct _SLL_DATE{sll_year_t year;sll_month_t month;sll_day_t day;sll_day_t week_day;sll_hour_t hour;sll_minute_t minute;sll_second_t second;sll_time_zone_t time_zone;} sll_date_t;
typedef unsigned char sll_json_object_type_t;
typedef unsigned int sll_json_array_length_t;
typedef unsigned int sll_json_map_length_t;
typedef const sll_char_t* sll_json_parser_state_t;
typedef struct _SLL_JSON_ARRAY{struct _SLL_JSON_OBJECT* data;sll_json_array_length_t length;} sll_json_array_t;
typedef struct _SLL_JSON_MAP{struct _SLL_JSON_MAP_KEYPAIR* data;sll_json_map_length_t length;} sll_json_map_t;
typedef union _SLL_JSON_OBJECT_DATA{sll_integer_t int_;sll_float_t float_;sll_string_t string;sll_json_array_t array;sll_json_map_t map;} sll_json_object_data_t;
typedef struct _SLL_JSON_OBJECT{sll_json_object_type_t type;sll_json_object_data_t data;} sll_json_object_t;
typedef struct _SLL_JSON_MAP_KEYPAIR{sll_string_t key;sll_json_object_t value;} sll_json_map_keypair_t;
typedef struct _SLL_LOADED_LIBRARY{const sll_string_t name;sll_library_handle_t handle;} sll_loaded_library_t;
typedef unsigned char sll_process_creation_flags_t;
typedef struct _SLL_FACTOR{sll_size_t number;sll_size_t power;} sll_factor_t;
typedef struct _SLL_MD5_DATA{unsigned int a;unsigned int b;unsigned int c;unsigned int d;} sll_md5_data_t;
typedef struct _SLL_SHA1_DATA{unsigned int a;unsigned int b;unsigned int c;unsigned int d;unsigned int e;} sll_sha1_data_t;
typedef struct _SLL_SHA512_DATA{unsigned long long int a;unsigned long long int b;unsigned long long int c;unsigned long long int d;unsigned long long int e;unsigned long long int f;unsigned long long int g;unsigned long long int h;} sll_sha512_data_t;
typedef unsigned char sll_object_function_index_t;
typedef unsigned int sll_object_type_table_length_t;
typedef struct _SLL_OBJECT_TYPE_DATA_FIELD{sll_object_type_t type;sll_bool_t read_only;sll_string_t name;} sll_object_type_data_field_t;
typedef struct _SLL_OBJECT_TYPE_DATA{const sll_string_t name;sll_arg_count_t field_count;unsigned int _hash_table_bit_mask;sll_arg_count_t* _hash_table;unsigned long long int _rng;sll_integer_t functions[SLL_MAX_OBJECT_FUNC+1];sll_object_type_data_field_t fields[];} sll_object_type_data_t;
typedef struct _SLL_OBJECT_TYPE_TABLE{const sll_object_type_data_t** data;sll_object_type_table_length_t length;} sll_object_type_table_t;
typedef void* sll_weak_reference_t;
typedef void (*sll_weak_ref_destructor_t)(sll_weak_reference_t wr,sll_object_t* object,void* arg);
typedef unsigned char sll_execution_flags_t;
typedef unsigned short int sll_call_stack_size_t;
typedef struct _SLL_CALL_STACK_FRAME{sll_instruction_index_t _instruction_index;sll_stack_offset_t _stack_offset;void* _variable_memory_offset;} sll_call_stack_frame_t;
typedef struct _SLL_CALL_STACK{sll_call_stack_frame_t* data;sll_call_stack_size_t length;} sll_call_stack_t;
typedef void* sll_internal_function_pointer_t;
typedef struct _SLL_INTERNAL_FUNCTION{sll_string_t name;sll_internal_function_pointer_t function;sll_char_t* format;unsigned short int _return_value;sll_arg_count_t _arg_count;sll_size_t _arg_size;unsigned long long int* _registers;} sll_internal_function_t;
typedef struct _SLL_INTERNAL_FUNCTION_TABLE{const sll_internal_function_t* data;sll_function_index_t length;} sll_internal_function_table_t;
typedef struct _SLL_RUNTIME_DATA{const sll_assembly_data_t* assembly_data;sll_internal_function_table_t* internal_function_table;sll_object_type_table_t* type_table;} sll_runtime_data_t;
typedef struct _SLL_VM_CONFIG{sll_size_t s_sz;sll_size_t call_stack_size;sll_internal_function_table_t* internal_function_table;sll_file_t* in;sll_file_t* out;sll_file_t* err;} sll_vm_config_t;
typedef void (*sll_cleanup_function_t)(void);
typedef struct _SLL_INTERNAL_FUNCTION_DESCRIPTOR{const sll_char_t* name;const sll_internal_function_pointer_t function;const sll_char_t* format;} sll_internal_function_descriptor_t;
typedef struct _SLL_INTERNAL_FUNCTION_TABLE_DESCRIPTOR{const sll_internal_function_descriptor_t* data;sll_function_index_t length;} sll_internal_function_table_descriptor_t;
typedef unsigned char sll_sandbox_flag_t;
typedef unsigned long long int sll_sandbox_flags_t;
extern sll_file_t* sll_stdin;
extern sll_file_t* sll_stdout;
extern sll_file_t* sll_stderr;
extern const sll_time_zone_t* sll_platform_time_zone;
extern const sll_string_t* sll_executable_file_path;
extern const sll_string_t* sll_library_file_path;
extern const sll_string_t* sll_temporary_file_path;
extern const sll_cpu_t* sll_platform_cpu_count;
extern const sll_string_t* sll_platform_string;
extern const sll_environment_t* sll_environment;
extern const sll_search_path_t* sll_environment_path;
extern const sll_time_zone_t* sll_utc_time_zone;
extern const sll_runtime_data_t* sll_current_runtime_data;
extern const sll_vm_config_t* sll_current_vm_config;
extern sll_object_t* sll_static_int[256];
extern sll_object_t* sll_static_negative_int[16];
extern sll_object_t* sll_static_float_zero;
extern sll_object_t* sll_static_float_one;
extern sll_object_t* sll_static_float_half;
extern sll_object_t* sll_static_char[256];
extern sll_object_t* sll_static_complex_zero;
extern const sll_internal_function_table_descriptor_t* sll_builtin_internal_functions;
__attribute__((warn_unused_result)) sll_semaphore_index_t sll_semaphore_create(sll_semaphore_counter_t count);
__attribute__((warn_unused_result)) sll_bool_t sll_semaphore_delete(sll_semaphore_index_t sempahore_index);
__attribute__((warn_unused_result)) sll_bool_t sll_semaphore_release(sll_semaphore_index_t sempahore_index);
__attribute__((warn_unused_result)) sll_error_t sll_error_from_string_pointer(const sll_char_t* string);
__attribute__((warn_unused_result)) const sll_char_t* sll_error_get_string_pointer(sll_error_t err);
void sll_audit(const sll_char_t* name,const sll_char_t* format,...);
sll_bool_t sll_audit_enable(sll_bool_t enable);
void sll_audit_list(const sll_char_t* name,const sll_char_t* format,sll_var_arg_list_t* va);
void sll_audit_register_callback(sll_audit_callback_t callback);
sll_bool_t sll_audit_unregister_callback(sll_audit_callback_t callback);
__attribute__((warn_unused_result)) void* sll_var_arg_get(sll_var_arg_list_t* va);
__attribute__((warn_unused_result)) sll_char_t sll_var_arg_get_char(sll_var_arg_list_t* va);
void sll_var_arg_get_complex(sll_var_arg_list_t* va,sll_complex_t* out);
__attribute__((warn_unused_result)) sll_float_t sll_var_arg_get_float(sll_var_arg_list_t* va);
__attribute__((warn_unused_result)) sll_integer_t sll_var_arg_get_int(sll_var_arg_list_t* va);
__attribute__((warn_unused_result)) sll_object_t* sll_var_arg_get_object(sll_var_arg_list_t* va);
void sll_var_arg_get_string(sll_var_arg_list_t* va,sll_string_t* out);
void sll_debug_print_assembly(const sll_assembly_data_t* assembly_data);
void sll_debug_print_node(const sll_node_t* node,const sll_source_file_t* source_file);
void sll_debug_print_object(sll_object_t* object);
__attribute__((warn_unused_result)) sll_version_t sll_version(void);
__attribute__((warn_unused_result)) const sll_char_t* sll_version_sha(void);
__attribute__((warn_unused_result)) const sll_char_t* sll_version_string(void);
__attribute__((warn_unused_result)) const sll_char_t* sll_version_tag(void);
void sll_free_tls(sll_tls_object_t* tls);
__attribute__((warn_unused_result)) sll_object_t** sll_tls_get(sll_tls_object_t* tls);
void sll_free_assembly_data(sll_assembly_data_t* assembly_data);
void sll_generate_assembly(const sll_source_file_t* source_file,sll_assembly_data_t* out);
void sll_print_assembly(const sll_assembly_data_t* assembly_data,sll_file_t* out);
__attribute__((warn_unused_result)) sll_barrier_index_t sll_barrier_create(void);
__attribute__((warn_unused_result)) sll_bool_t sll_barrier_delete(sll_barrier_index_t barrier_indexarrier_index);
__attribute__((warn_unused_result)) sll_barrier_counter_t sll_barrier_increase(sll_barrier_index_t barrier_index);
__attribute__((warn_unused_result)) sll_bool_t sll_barrier_reset(sll_barrier_index_t barrier_index);
void sll_free_map(sll_map_t* map);
void sll_map_add(const sll_map_t* map,sll_object_t* key,sll_object_t* value,sll_map_t* out);
void sll_map_add_array(const sll_map_t* map,const sll_array_t* array,sll_map_t* out);
void sll_map_add_string(const sll_map_t* map,const sll_string_t* string,sll_map_t* out);
void sll_map_and(const sll_map_t* a,const sll_map_t* b,sll_map_t* out);
void sll_map_and_array(const sll_map_t* map,const sll_array_t* array,sll_map_t* out);
void sll_map_and_string(const sll_map_t* map,const sll_string_t* string,sll_map_t* out);
void sll_map_clone(const sll_map_t* map,sll_map_t* out);
__attribute__((warn_unused_result)) sll_compare_result_t sll_map_compare(const sll_map_t* a,const sll_map_t* b);
void sll_map_create(sll_map_length_t length,sll_map_t* out);
__attribute__((warn_unused_result)) sll_bool_t sll_map_equal(const sll_map_t* a,const sll_map_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_map_get(const sll_map_t* map,sll_object_t* key);
__attribute__((warn_unused_result)) sll_object_t* sll_map_get_key(const sll_map_t* map,sll_map_length_t index);
__attribute__((warn_unused_result)) sll_object_t* sll_map_get_value(const sll_map_t* map,sll_map_length_t index);
__attribute__((warn_unused_result)) sll_bool_t sll_map_includes(const sll_map_t* map,sll_object_t* key);
void sll_map_join(const sll_map_t* a,const sll_map_t* b,sll_map_t* out);
void sll_map_keys(const sll_map_t* map,sll_array_t* out);
void sll_map_op(const sll_map_t* a,const sll_map_t* b,sll_binary_operator_t operator,sll_map_t* out);
__attribute__((warn_unused_result)) sll_object_t* sll_map_remove(const sll_map_t* map,sll_object_t* key,sll_map_t* out);
void sll_map_remove_array(const sll_map_t* map,const sll_array_t* array,sll_map_t* out);
void sll_map_remove_map(const sll_map_t* a,const sll_map_t* b,sll_map_t* out);
void sll_map_remove_string(const sll_map_t* map,const sll_string_t* string,sll_map_t* out);
void sll_map_set(sll_map_t* m,sll_object_t* key,sll_object_t* value);
void sll_map_set_key(const sll_map_t* map,sll_map_length_t index,sll_object_t* key);
void sll_map_set_value(const sll_map_t* map,sll_map_length_t index,sll_object_t* value);
void sll_map_to_array(const sll_map_t* map,sll_array_t* out);
void sll_map_values(const sll_map_t* map,sll_array_t* out);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_access(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_access_range(sll_object_t* a,sll_object_t* b,sll_object_t* c);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_access_range_step(sll_object_t* a,sll_object_t* b,sll_object_t* c,sll_object_t* d);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_add(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_and(sll_object_t* a,sll_object_t* b);
void sll_operator_assign(sll_object_t* a,sll_object_t* b,sll_object_t* v);
void sll_operator_assign_range(sll_object_t* a,sll_object_t* b,sll_object_t* c,sll_object_t* v);
void sll_operator_assign_range_step(sll_object_t* a,sll_object_t* b,sll_object_t* c,sll_object_t* d,sll_object_t* v);
__attribute__((warn_unused_result)) sll_bool_t sll_operator_bool(sll_object_t* a);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_cast(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_compare_result_t sll_operator_compare(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_dec(sll_object_t* a);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_div(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_copy(sll_object_t* a,sll_bool_t d);
__attribute__((warn_unused_result)) sll_bool_t sll_operator_equal(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_floor_div(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_inc(sll_object_t* a);
__attribute__((warn_unused_result)) sll_bool_t sll_operator_includes(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_inv(sll_object_t* a);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_len(sll_object_t* a);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_mod(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_mult(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_or(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_shl(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_shr(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_bool_t sll_operator_strict_equal(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_sub(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_object_t* sll_operator_xor(sll_object_t* a,sll_object_t* b);
__attribute__((warn_unused_result)) sll_compare_result_t sll_compare_data(const void* a,const void* b,sll_size_t length);
__attribute__((warn_unused_result)) sll_bool_t sll_contains_character(const void* pointer,sll_size_t length,sll_char_t char_);
void sll_copy_data(const void* source,sll_size_t length,void* target);
void sll_copy_objects(sll_object_t*const* source,sll_size_t count,sll_object_t** target);
void* sll_copy_string(const sll_char_t* source,void* target);
void sll_copy_string_null(const sll_char_t* source,void* target);
void sll_set_memory(void* pointer,sll_size_t length,sll_char_t value);
void sll_zero_memory(void* pointer,sll_size_t length);
void sll_container_clear(sll_container_t* c);
void sll_container_filter(sll_container_t* c,sll_size_t elem_size,sll_container_check_callback_t check,sll_container_callback_t delete);
void sll_container_init(sll_container_t* c);
void sll_container_iter(sll_container_t* c,sll_size_t elem_size,sll_container_callback_t callback);
void sll_container_iter_clear(sll_container_t* c,sll_size_t elem_size,sll_container_callback_t callback);
void sll_container_push(sll_container_t* c,const void* elem,sll_size_t elem_size);
__attribute__((warn_unused_result)) sll_size_t sll_handle_container_alloc(sll_handle_container_t* c);
void sll_handle_container_clear(sll_handle_container_t* c);
__attribute__((warn_unused_result)) sll_bool_t sll_handle_container_check(sll_handle_container_t* c,sll_size_t index);
void sll_handle_container_dealloc(sll_handle_container_t* c,sll_size_t index);
__attribute__((warn_unused_result)) void* sll_handle_container_get(sll_handle_container_t* c,sll_size_t index);
void sll_handle_container_init(sll_handle_container_t* c);
void sll_handle_container_iter(sll_handle_container_t* c,sll_container_callback_t callback);
void sll_handle_container_iter_clear(sll_handle_container_t* c,sll_container_callback_t callback);
void sll_bundle_add_file(const sll_char_t* name,sll_compilation_data_t* compilation_data,sll_bundle_t* out);
void sll_bundle_create(const sll_char_t* name,sll_bundle_t* out);
__attribute__((warn_unused_result)) sll_bool_t sll_bundle_fetch(const sll_bundle_t* bundle,const sll_string_t* name,sll_compilation_data_t* out);
void sll_free_bundle(sll_bundle_t* bundle);
__attribute__((warn_unused_result)) sll_lock_index_t sll_lock_create(void);
__attribute__((warn_unused_result)) sll_bool_t sll_lock_delete(sll_lock_index_t lock_index);
__attribute__((warn_unused_result)) sll_bool_t sll_lock_release(sll_lock_index_t lock_index);
__attribute__((warn_unused_result)) sll_cpu_t sll_get_cpu_index(void);
__attribute__((warn_unused_result)) sll_thread_index_t sll_get_thread_index(void);
void sll_file_close(sll_file_t* file);
__attribute__((warn_unused_result)) sll_bool_t sll_file_data_available(sll_file_t* file);
__attribute__((warn_unused_result)) sll_error_t sll_file_flush(sll_file_t* file);
void sll_file_from_data(const void* pointer,sll_size_t size,sll_file_flags_t flags,sll_file_t* out);
void sll_file_get_buffer(void* p,sll_file_t* file,sll_string_t* out);
sll_error_t sll_file_open(const sll_char_t* name,sll_file_flags_t flags,sll_file_t* out);
void sll_file_open_descriptor(const sll_char_t* name,sll_file_descriptor_t fd,sll_file_flags_t flags,sll_file_t* out);
__attribute__((warn_unused_result)) sll_read_char_t sll_file_peek_char(sll_file_t* file,sll_error_t* err);
__attribute__((warn_unused_result)) sll_size_t sll_file_read(sll_file_t* file,void* pointer,sll_size_t size,sll_error_t* err);
__attribute__((warn_unused_result)) sll_error_t sll_file_read_all(sll_file_t* file,sll_string_t* out);
sll_read_char_t sll_file_read_char(sll_file_t* file,sll_error_t* err);
__attribute__((warn_unused_result)) sll_error_t sll_file_reset(sll_file_t* file);
__attribute__((warn_unused_result)) sll_size_t sll_file_write(sll_file_t* file,const void* pointer,sll_size_t size,sll_error_t* err);
__attribute__((warn_unused_result)) sll_bool_t sll_file_write_char(sll_file_t* file,sll_char_t char_,sll_error_t* err);
__attribute__((warn_unused_result)) sll_size_t sll_file_write_char_count(sll_file_t* file,sll_char_t char_,sll_size_t count,sll_error_t* err);
__attribute__((warn_unused_result)) sll_size_t sll_file_write_format(sll_file_t* file,const sll_char_t* format,sll_error_t* err,...);
__attribute__((warn_unused_result)) sll_size_t sll_file_write_string(sll_file_t* file,const sll_char_t* string,sll_error_t* err);
__attribute__((warn_unused_result)) sll_time_t sll_platform_get_current_time(void);
void sll_platform_sleep(sll_time_t tm);
__attribute__((warn_unused_result)) sll_string_length_t sll_platform_get_library_file_path(sll_library_handle_t h,sll_char_t* fp,sll_string_length_t fpl,sll_error_t* err);
__attribute__((warn_unused_result)) sll_library_handle_t sll_platform_load_library(const sll_char_t* fp,sll_error_t* err);
__attribute__((warn_unused_result)) void* sll_platform_lookup_symbol(sll_library_handle_t h,const sll_char_t* nm);
__attribute__((warn_unused_result)) sll_error_t sll_platform_unload_library(sll_library_handle_t h);
__attribute__((warn_unused_result)) sll_event_handle_t sll_platform_event_create(sll_error_t* err);
__attribute__((warn_unused_result)) sll_error_t sll_platform_event_delete(sll_event_handle_t e);
__attribute__((warn_unused_result)) sll_error_t sll_platform_event_set(sll_event_handle_t e);
__attribute__((warn_unused_result)) sll_error_t sll_platform_event_wait(sll_event_handle_t e);
sll_string_length_t sll_platform_absolute_path(const sll_char_t* fp,sll_char_t* o,sll_string_length_t ol);
__attribute__((warn_unused_result)) sll_error_t sll_platform_create_directory(const sll_char_t* fp,sll_bool_t all);
__attribute__((warn_unused_result)) sll_string_length_t sll_platform_get_current_working_directory(sll_char_t* o,sll_string_length_t ol,sll_error_t* err);
__attribute__((warn_unused_result)) sll_array_length_t sll_platform_list_directory(const sll_char_t* fp,sll_string_t** o,sll_error_t* err);
__attribute__((warn_unused_result)) sll_array_length_t sll_platform_list_directory_recursive(const sll_char_t* fp,sll_string_t** o,sll_error_t* err);
__attribute__((warn_unused_result)) sll_error_t sll_platform_path_copy(const sll_char_t* s,const sll_char_t* d);
__attribute__((warn_unused_result)) sll_error_t sll_platform_path_delete(const sll_char_t* fp);
__attribute__((warn_unused_result)) sll_bool_t sll_platform_path_exists(const sll_char_t* fp);
__attribute__((warn_unused_result)) sll_bool_t sll_platform_path_is_directory(const sll_char_t* fp);
__attribute__((warn_unused_result)) sll_error_t sll_platform_path_rename(const sll_char_t* s,const sll_char_t* d);
__attribute__((warn_unused_result)) sll_error_t sll_platform_set_current_working_directory(const sll_char_t* p);
__attribute__((warn_unused_result)) sll_error_t sll_platform_lock_acquire(sll_lock_handle_t l);
__attribute__((warn_unused_result)) sll_lock_handle_t sll_platform_lock_create(sll_error_t* err);
__attribute__((warn_unused_result)) sll_error_t sll_platform_lock_delete(sll_lock_handle_t l);
__attribute__((warn_unused_result)) sll_error_t sll_platform_lock_release(sll_lock_handle_t l);
__attribute__((warn_unused_result)) sll_bool_t sll_platform_file_async_read(sll_file_descriptor_t fd);
__attribute__((warn_unused_result)) sll_error_t sll_platform_file_close(sll_file_descriptor_t fd);
__attribute__((warn_unused_result)) sll_bool_t sll_platform_file_data_available(sll_file_descriptor_t fd);
__attribute__((warn_unused_result)) sll_file_descriptor_t sll_platform_file_open(const sll_char_t* fp,sll_file_flags_t ff,sll_error_t* err);
__attribute__((warn_unused_result)) sll_size_t sll_platform_file_read(sll_file_descriptor_t fd,void* p,sll_size_t sz,sll_error_t* err);
__attribute__((warn_unused_result)) sll_error_t sll_platform_file_seek(sll_file_descriptor_t fd,sll_file_offset_t off);
__attribute__((warn_unused_result)) sll_size_t sll_platform_file_size(sll_file_descriptor_t fd,sll_error_t* err);
sll_size_t sll_platform_file_write(sll_file_descriptor_t fd,const void* p,sll_size_t sz,sll_error_t* err);
__attribute__((warn_unused_result)) sll_file_descriptor_t sll_platform_get_default_stream_descriptor(sll_char_t t);
void sll_platform_remove_environment_variable(const sll_char_t* k);
void sll_platform_set_environment_variable(const sll_char_t* k,const sll_char_t* v);
__attribute__((warn_unused_result)) sll_internal_thread_index_t sll_platform_current_thread(void);
__attribute__((warn_unused_result)) sll_error_t sll_platform_join_thread(sll_internal_thread_index_t tid);
__attribute__((warn_unused_result)) sll_error_t sll_platform_set_cpu(sll_cpu_t cpu);
__attribute__((warn_unused_result)) sll_internal_thread_index_t sll_platform_start_thread(sll_internal_thread_function_t fn,void* arg,sll_error_t* err);
__attribute__((warn_unused_result)) sll_error_t sll_platform_get_error(void);
void sll_platform_random(void* bf,sll_size_t l);
__attribute__((warn_unused_result)) sll_error_t sll_platform_close_process_handle(sll_process_handle_t ph);
__attribute__((warn_unused_result)) sll_bool_t sll_platform_execute_shell(const sll_char_t* cmd,sll_error_t* err);
__attribute__((warn_unused_result)) sll_pid_t sll_platform_get_pid(void);
__attribute__((warn_unused_result)) sll_process_handle_t sll_platform_start_process(const sll_char_t*const* a,const sll_char_t*const* env,sll_error_t* err);
__attribute__((warn_unused_result)) sll_return_code_t sll_platform_wait_process(sll_process_handle_t ph,sll_error_t* err);
__attribute__((warn_unused_result)) void* sll_platform_allocate_page(sll_size_t size,sll_bool_t large,sll_error_t* err);
__attribute__((warn_unused_result)) void* sll_platform_allocate_page_aligned(sll_size_t size,sll_size_t align,sll_error_t* err);
__attribute__((warn_unused_result)) sll_error_t sll_platform_free_page(void* ptr,sll_size_t size);
void sll_free_search_path(sll_search_path_t* search_path);
void sll_search_path_create(const sll_string_t* string,sll_search_path_t* out);
__attribute__((warn_unused_result)) sll_bool_t sll_search_path_find(const sll_search_path_t* search_path,const sll_string_t* name,sll_search_flags_t flag,sll_string_t* out);
void sll_search_path_from_environment(const sll_string_t* key,sll_search_path_t* out);
void sll__gc_error(sll_object_t* object);
void sll__release_object_internal(sll_object_t* object);
void sll_acquire_object(sll_object_t* object);
__attribute__((warn_unused_result)) sll_object_t* sll_create_object(sll_object_type_t type);
__attribute__((warn_unused_result)) sll_bool_t sll_destroy_object(sll_object_t* object);
void sll_gc_add_root(sll_object_t* object,sll_bool_t fast);
void sll_gc_add_roots(sll_object_t*const* pointer,sll_size_t length);
void sll_gc_collect( void);
void sll_gc_remove_root(sll_object_t* object);
void sll_gc_remove_roots(sll_object_t*const* pointer);
void sll_release_object(sll_object_t* object);
void sll_compilation_data_from_source_file(const sll_source_file_t* source_file,sll_compilation_data_t* out);
void sll_free_compilation_data(sll_compilation_data_t* compilation_data);
void sll_free_source_file(sll_source_file_t* source_file);
__attribute__((warn_unused_result)) sll_node_offset_t sll_get_node_size(const sll_node_t* node);
void sll_init_compilation_data(const sll_char_t* file_path,sll_compilation_data_t* out);
void sll_optimize_metadata(sll_compilation_data_t* compilation_data);
void sll_parse_nodes(sll_file_t* file,sll_compilation_data_t* compilation_data,sll_internal_function_table_t* internal_function_table,sll_import_resolver_t import_resolver);
void sll_print_node(const sll_source_file_t* source_file,const sll_internal_function_table_t* internal_function_table,const sll_node_t* node,sll_file_t* out);
void sll_remove_debug_data(sll_compilation_data_t* compilation_data);
void sll_remove_debug_names(sll_compilation_data_t* compilation_data);
void sll_remove_node_padding(sll_compilation_data_t* compilation_data);
__attribute__((warn_unused_result)) sll_node_t* sll_skip_node(sll_node_t* node);
__attribute__((warn_unused_result)) const sll_node_t* sll_skip_node_const(const sll_node_t* node);
void sll_unify_compilation_data(const sll_compilation_data_t* compilation_data,sll_source_file_t* out);
__attribute__((warn_unused_result)) sll_compressed_integer_t sll_compress_integer(sll_size_t int_);
__attribute__((warn_unused_result)) sll_size_t sll_decompress_integer(sll_compressed_integer_t compressed_int);
sll_identifier_index_t sll_identifier_add_index(sll_identifier_index_t identifier_index,sll_identifier_index_t delta_index);
sll_identifier_index_t sll_identifier_create(sll_identifier_index_t index,sll_identifier_index_t id);
sll_identifier_index_t sll_identifier_get_array_id(sll_identifier_index_t identifier_index);
sll_identifier_index_t sll_identifier_get_array_index(sll_identifier_index_t identifier_index);
__attribute__((warn_unused_result)) sll_string_index_t sll_identifier_get_string_index(sll_identifier_t* identifier);
__attribute__((warn_unused_result)) sll_bool_t sll_identifier_is_tls(sll_identifier_t* identifier);
void sll_identifier_set_string_index(sll_identifier_t* identifier,sll_string_index_t name_string_index,sll_bool_t tls);
void sll_identifier_update_string_index(sll_identifier_t* identifier,sll_string_index_t name_string_index);
sll_bool_t sll_expand_environment_variable(const sll_string_t* key,sll_string_t* out);
sll_bool_t sll_get_environment_variable(const sll_string_t* key,sll_string_t* out);
void sll_remove_environment_variable(const sll_string_t* key);
void sll_set_environment_variable(const sll_string_t* key,const sll_string_t* value);
void sll_cli_expand_path(const sll_char_t* path,sll_char_t* out);
__attribute__((warn_unused_result)) sll_cli_lookup_result_t sll_cli_lookup_file(const sll_string_t* path,sll_bool_t use_custom_resolvers,sll_cli_lookup_data_t* out);
__attribute__((warn_unused_result)) sll_return_code_t sll_cli_main(sll_array_length_t argc,const sll_char_t*const* argv);
void sll_cli_register_path_resolver(sll_cli_path_resolver_t function);
sll_bool_t sll_cli_unregister_path_resolver(sll_cli_path_resolver_t function);
void sll_optimize_source_file(sll_source_file_t* source_file,sll_optimization_round_count_t round_count);
__attribute__((warn_unused_result)) sll_thread_index_t sll_thread_create(sll_integer_t function,sll_object_t*const* args,sll_arg_count_t arg_count);
__attribute__((warn_unused_result)) sll_bool_t sll_thread_delete(sll_thread_index_t thread_index);
__attribute__((warn_unused_result)) const sll_call_stack_t* sll_thread_get_call_stack(sll_thread_index_t thread_index);
__attribute__((warn_unused_result)) sll_instruction_index_t sll_thread_get_instruction_index(sll_thread_index_t thread_index);
__attribute__((warn_unused_result)) sll_bool_t sll_thread_restart(sll_thread_index_t thread_index);
__attribute__((warn_unused_result)) sll_bool_t sll_thread_start(sll_thread_index_t thread_index);
__attribute__((warn_unused_result)) sll_bool_t sll_thread_suspend(sll_thread_index_t thread_index);
__attribute__((warn_unused_result)) sll_string_index_t sll_add_string(sll_string_table_t* string_table,sll_string_t* string);
sll_bool_t sll_log(const sll_char_t* file_path,const sll_char_t* function_name,sll_file_offset_t line,sll_bool_t is_warning,const sll_char_t* format,...);
sll_bool_t sll_log_raw(const sll_char_t* file_path,const sll_char_t* function_name,sll_file_offset_t line,sll_bool_t is_warning,const sll_string_t* string);
__attribute__((warn_unused_result)) sll_bool_t sll_set_log_flags(const sll_char_t* file_path,const sll_char_t* function_name,sll_logger_flags_t flags,sll_bool_t state);
void sll_allocator_collapse(void** pointer,sll_size_t size);
__attribute__((warn_unused_result)) void* sll_allocator_from_memory(void* pointer,sll_size_t size);
__attribute__((warn_unused_result)) void* sll_allocator_init(sll_size_t size);
void sll_allocator_move(void** pointer,sll_bool_t direction);
void sll_allocator_release(void* pointer);
void sll_allocator_resize(void** pointer,sll_size_t size);
void sll_free_args(sll_arg_state_t arg_state);
__attribute__((warn_unused_result)) sll_arg_count_t sll_parse_arg_count(const sll_char_t* format);
__attribute__((warn_unused_result)) sll_arg_state_t sll_parse_args(const sll_char_t* format,sll_object_t*const* args,sll_arg_count_t arg_count,...);
__attribute__((warn_unused_result)) sll_arg_state_t sll_parse_args_list(const sll_char_t* format,sll_object_t*const* args,sll_arg_count_t arg_count,va_list* va);
__attribute__((warn_unused_result)) sll_bool_t sll_load_assembly(sll_file_t* file,sll_assembly_data_t* out);
__attribute__((warn_unused_result)) sll_bool_t sll_load_bundle(sll_file_t* file,sll_bundle_t* out);
__attribute__((warn_unused_result)) sll_bool_t sll_load_compiled_node(sll_file_t* file,sll_compilation_data_t* out);
void sll_write_assembly(const sll_assembly_data_t* assembly_data,sll_file_t* out);
void sll_write_bundle(const sll_bundle_t* bundle,sll_file_t* out);
void sll_write_compiled_node(const sll_compilation_data_t* compilation_data,sll_file_t* out);
void sll_array_and(const sll_array_t* a,const sll_array_t* b,sll_array_t* out);
void sll_array_clone(const sll_array_t* array,sll_array_t* out);
__attribute__((warn_unused_result)) sll_array_length_t sll_array_count(const sll_array_t* array,sll_object_t* object);
__attribute__((warn_unused_result)) sll_array_length_t sll_array_count_multiple(const sll_array_t* array,sll_object_t*const* object_data,sll_array_length_t object_count);
void sll_array_combinations(const sll_array_t* a,const sll_array_t* b,sll_array_t* out);
void sll_array_combinations_string(const sll_array_t* array,const sll_string_t* string,sll_array_t* out);
__attribute__((warn_unused_result)) sll_compare_result_t sll_array_compare(const sll_array_t* a,const sll_array_t* b);
__attribute__((warn_unused_result)) sll_compare_result_t sll_array_compare_map(const sll_array_t* array,const sll_map_t* map,sll_bool_t inv);
void sll_array_create(sll_array_length_t length,sll_array_t* out);
void sll_array_create_zero(sll_array_length_t length,sll_array_t* out);
void sll_array_duplicate(const sll_array_t* array,sll_integer_t count,sll_array_length_t extra,sll_array_t* out);
__attribute__((warn_unused_result)) sll_bool_t sll_array_equal(const sll_array_t* a,const sll_array_t* b);
__attribute__((warn_unused_result)) sll_bool_t sll_array_equal_map(const sll_array_t* array,const sll_map_t* map);
void sll_array_extend(const sll_array_t* base,const sll_array_t* new,sll_array_t* out);
__attribute__((warn_unused_result)) sll_object_t* sll_array_get(const sll_array_t* array,sll_array_length_t index);
__attribute__((warn_unused_result)) sll_bool_t sll_array_includes(const sll_array_t* array,sll_object_t* object);
void sll_array_join_arrays(const sll_array_t*const* array_data,sll_array_length_t array_count,sll_object_t* infix,sll_array_t* out);
void sll_array_op(const sll_array_t* a,const sll_array_t* b,sll_binary_operator_t operator,sll_array_t* out);
void sll_array_op_map(const sll_array_t* array,const sll_map_t* map,sll_binary_operator_t operator,sll_bool_t inv,sll_map_t* out);
void sll_array_or(const sll_array_t* a,const sll_array_t* b,sll_array_t* out);
__attribute__((warn_unused_result)) sll_char_t sll_array_parse_char(const sll_array_t* array);
__attribute__((warn_unused_result)) sll_float_t sll_array_parse_float(const sll_array_t* array);
__attribute__((warn_unused_result)) sll_integer_t sll_array_parse_int(const sll_array_t* array);
__attribute__((warn_unused_result)) sll_object_t* sll_array_pop(const sll_array_t* array,sll_array_t* out);
void sll_array_push(const sll_array_t* array,sll_object_t* object,sll_array_t* out);
void sll_array_range(sll_integer_t start,sll_integer_t end,sll_integer_t step,sll_array_t* out);
void sll_array_remove(const sll_array_t* array,sll_object_t* object,sll_array_t* out);
void sll_array_remove_multiple(const sll_array_t* array,sll_object_t** object_data,sll_array_length_t object_count,sll_array_t* out);
void sll_array_replace(const sll_array_t* array,sll_object_t* key,sll_object_t* value,sll_array_t* out);
void sll_array_resize(const sll_array_t* array,sll_integer_t delta,sll_array_t* out);
void sll_array_reverse(const sll_array_t* array,sll_array_t* out);
void sll_array_select(const sll_array_t* array,sll_integer_t start,sll_integer_t end,sll_integer_t step,sll_array_t* out);
void sll_array_split(const sll_array_t* array,sll_object_t* object,sll_array_t* out);
void sll_array_set(const sll_array_t* array,sll_array_length_t index,sll_object_t* object);
__attribute__((warn_unused_result)) sll_object_t* sll_array_shift(const sll_array_t* array,sll_array_t* out);
void sll_array_to_map(const sll_array_t* array,sll_map_t* out);
void sll_array_unshift(const sll_array_t* array,sll_object_t* object,sll_array_t* out);
void sll_array_xor(const sll_array_t* a,const sll_array_t* b,sll_array_t* out);
void sll_free_array(sll_array_t* array);
__attribute__((warn_unused_result)) sll_object_t* sll_new_object(const sll_char_t* format,...);
void sll_new_object_array(const sll_char_t* format,sll_array_t* out,...);
void sll_new_object_array_list(const sll_char_t* format,sll_string_length_t format_length,sll_var_arg_list_t* va,sll_array_t* out);
__attribute__((warn_unused_result)) sll_object_t* sll_new_object_list(const sll_char_t* format,sll_string_length_t format_length,sll_var_arg_list_t* va);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_time_current(void);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_time_t sll_api_time_current_ns(void);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_time_sleep(const sll_number_t* time);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_time_t sll_api_time_sleep_ns(const sll_number_t* time);
__attribute__((ms_abi)) void sll_api_error_get_call_stack(sll_call_stack_size_t pop,sll_thread_index_t thread_index,sll_array_t* out);
__attribute__((ms_abi)) void sll_api_error_get_error_string(sll_error_t err,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_audit__init(sll_integer_t callback);
__attribute__((ms_abi)) void sll_api_audit_audit(const sll_string_t* name,const sll_string_t* format,sll_object_t*const* args,sll_arg_count_t arg_count);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_base64_decode(const sll_string_t* string,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_base64_encode(const sll_string_t* string,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_map_extend(sll_map_t* map,const sll_map_t* new);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_map_length_t sll_api_map_remove(sll_map_t* map,sll_object_t* key);
__attribute__((ms_abi)) void sll_api_path_absolute(const sll_string_t* path,sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_path_exists(const sll_string_t* path);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_path_get_cwd(sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_path_is_dir(const sll_string_t* path);
__attribute__((ms_abi)) void sll_api_path_join(const sll_string_t*const* parts,sll_arg_count_t len,sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_path_list_dir(const sll_string_t* path,sll_bool_t recursive,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_path_mkdir(const sll_string_t* path,sll_bool_t all);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_path_set_cwd(const sll_string_t* path);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_path_size(const sll_string_t* path,sll_size_t* out);
__attribute__((ms_abi)) void sll_api_path_split(const sll_string_t* path,sll_array_t* out);
__attribute__((ms_abi)) void sll_api_path_split_drive(const sll_string_t* path,sll_array_t* out);
__attribute__((warn_unused_result)) sll_string_length_t sll_path_split(const sll_string_t* s);
__attribute__((warn_unused_result)) sll_string_length_t sll_path_split_drive(const sll_string_t* s);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_file_close(sll_file_handle_t handle);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_copy(const sll_string_t* src,const sll_string_t* dst);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_delete(const sll_string_t* path);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_file_flush(sll_file_handle_t handle);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_from_data(const sll_string_t* data,sll_file_flags_t flags,sll_file_handle_t* out);
__attribute__((ms_abi)) void sll_api_file_get_buffer(sll_file_handle_t handle,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_file_get_temp_path(sll_string_t* out);
__attribute__((ms_abi)) void sll_api_file_inc_handle(sll_file_handle_t handle);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_open(const sll_string_t* path,sll_file_flags_t flags,sll_file_handle_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_peek(sll_file_handle_t handle,sll_char_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_read(sll_file_handle_t handle,sll_string_length_t size,sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_read_char(sll_file_handle_t handle,sll_char_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_rename(const sll_string_t* src,const sll_string_t* dst);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_std_handle(sll_char_t id,sll_file_handle_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_file_write(sll_file_handle_t handle,const sll_string_t* data,sll_size_t* out);
__attribute__((warn_unused_result)) sll_file_t* sll_file_from_handle(sll_file_handle_t handle);
__attribute__((warn_unused_result)) sll_file_handle_t sll_file_to_handle(sll_file_t* f);
__attribute__((ms_abi)) void sll_api_atexit_register(sll_integer_t function,sll_object_t*const* args,sll_arg_count_t arg_count);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_atexit_unregister(sll_integer_t function);
__attribute__((ms_abi)) void sll_api_date_get_time_zone(sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_date_merge(sll_year_t year,sll_month_t month,sll_day_t day,sll_hour_t hour,sll_minute_t minute,sll_second_t second);
__attribute__((ms_abi)) void sll_api_date_split(sll_float_t time,sll_array_t* out);
void sll_date_from_time(sll_float_t time,const sll_time_zone_t* time_zone,sll_date_t* o);
void sll_date_from_time_ns(sll_time_t time,const sll_time_zone_t* time_zone,sll_date_t* o);
__attribute__((warn_unused_result)) sll_float_t sll_date_to_time(sll_date_t* date);
__attribute__((ms_abi)) void sll_api_int_to_bin(sll_integer_t number,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_int_to_dec(sll_integer_t number,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_int_to_hex(sll_integer_t number,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_int_to_oct(sll_integer_t number,sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_struct_double_from_bits(unsigned long long int value);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_struct_float_from_bits(unsigned int value);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) unsigned long long int sll_api_struct_double_to_bits(sll_float_t value);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) unsigned int sll_api_struct_float_to_bits(sll_float_t value);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_serial_decode_float(sll_file_handle_t hande,sll_float_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_serial_decode_integer(sll_file_handle_t hande,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_serial_decode_object(sll_file_handle_t hande,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_serial_decode_signed_integer(sll_file_handle_t hande,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_serial_decode_string(sll_file_handle_t hande,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_serial_encode_float(sll_file_handle_t hande,sll_float_t v);
__attribute__((ms_abi)) sll_error_t sll_api_serial_encode_integer(sll_file_handle_t hande,sll_size_t v);
__attribute__((ms_abi)) sll_error_t sll_api_serial_encode_object(sll_file_handle_t hande,const sll_array_t* args);
__attribute__((ms_abi)) sll_error_t sll_api_serial_encode_signed_integer(sll_file_handle_t hande,sll_integer_t v);
__attribute__((ms_abi)) sll_error_t sll_api_serial_encode_string(sll_file_handle_t hande,const sll_string_t* str);
__attribute__((warn_unused_result)) sll_size_t sll_decode_integer(sll_file_t* file,sll_error_t* err);
__attribute__((warn_unused_result)) sll_integer_t sll_decode_signed_integer(sll_file_t* file,sll_error_t* err);
__attribute__((warn_unused_result)) sll_object_t* sll_decode_object(sll_file_t* file,sll_error_t* err);
__attribute__((warn_unused_result)) sll_error_t sll_decode_string(sll_file_t* file,sll_string_t* out);
__attribute__((warn_unused_result)) sll_error_t sll_encode_integer(sll_file_t* file,sll_size_t v);
__attribute__((warn_unused_result)) sll_error_t sll_encode_signed_integer(sll_file_t* file,sll_integer_t v);
__attribute__((warn_unused_result)) sll_error_t sll_encode_object(sll_file_t* file,sll_object_t*const* args,sll_arg_count_t arg_count);
__attribute__((warn_unused_result)) sll_error_t sll_encode_string(sll_file_t* file,const sll_string_t* string);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_thread_create(sll_integer_t function,const sll_array_t* args,sll_thread_index_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_thread_create_barrier(sll_barrier_index_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_thread_create_lock(sll_lock_index_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_thread_create_semaphore(sll_semaphore_counter_t count,sll_lock_index_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_thread_delete(sll_thread_index_t thread_index);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_thread_delete_barrier(sll_barrier_index_t barrier_index);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_thread_delete_lock(sll_lock_index_t lock_index);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_thread_delete_semaphore(sll_semaphore_index_t sempahore_index);
__attribute__((ms_abi)) void sll_api_thread_get_internal_data(sll_thread_index_t thread_index,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_barrier_counter_t sll_api_thread_increase_barrier(sll_barrier_index_t barrier_index);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_thread_release_lock(sll_lock_index_t lock_index);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_thread_release_semaphore(sll_semaphore_index_t sempahore_index);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_barrier_counter_t sll_api_thread_reset_barrier(sll_barrier_index_t barrier_index);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_thread_restart(sll_thread_index_t thread_index);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_thread_suspend(sll_thread_index_t thread_index);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_log_log(sll_object_t*const* args,sll_arg_count_t arg_count);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_log_set(sll_string_t* file,sll_string_t* func,sll_logger_flags_t flags,sll_bool_t state);
__attribute__((ms_abi)) void sll_api_json__init(sll_object_t* null_obj,sll_object_t* true_obj,sll_object_t* false_obj);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_object_t* sll_api_json_parse(const sll_string_t* string);
__attribute__((ms_abi)) void sll_api_json_stringify(sll_object_t* json,sll_string_t* out);
void sll_free_json_object(sll_json_object_t* json);
__attribute__((warn_unused_result)) sll_json_object_t* sll_json_get_by_key(sll_json_object_t* json,const sll_string_t* key);
__attribute__((warn_unused_result)) sll_bool_t sll_json_parse(sll_json_parser_state_t* p,sll_json_object_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_array_length_t sll_api_array_count(const sll_array_t* array,sll_object_t* elem);
__attribute__((ms_abi)) void sll_api_array_create(sll_array_length_t length,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_array_length_t sll_api_array_extend(sll_array_t* array,const sll_array_t* new);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_array_index(const sll_array_t* array,sll_object_t* elem);
__attribute__((ms_abi)) void sll_api_array_join(const sll_array_t*const* array,sll_arg_count_t length,sll_object_t* elem,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_object_t* sll_api_array_pop(sll_array_t* array);
__attribute__((ms_abi)) sll_array_length_t sll_api_array_push(sll_array_t* array,sll_object_t* elem);
__attribute__((ms_abi)) sll_array_length_t sll_api_array_remove(sll_array_t* array,sll_object_t* elem);
__attribute__((ms_abi)) void sll_api_array_replace(const sll_array_t* array,sll_object_t* old,sll_object_t* new,sll_array_t* out);
__attribute__((ms_abi)) void sll_api_array_reverse(const sll_array_t* array,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_object_t* sll_api_array_shift(sll_array_t* array);
__attribute__((ms_abi)) void sll_api_array_split(const sll_array_t* array,sll_object_t* key,sll_array_t* out);
__attribute__((ms_abi)) sll_array_length_t sll_api_array_unshift(sll_array_t* array,sll_object_t* elem);
__attribute__((ms_abi)) void sll_api_sys_get_args(sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_cpu_t sll_api_sys_get_cpu_count(void);
__attribute__((ms_abi)) void sll_api_sys_get_env(sll_map_t* out);
__attribute__((ms_abi)) void sll_api_sys_get_executable(sll_string_t* out);
__attribute__((ms_abi)) void sll_api_sys_get_library(sll_string_t* out);
__attribute__((ms_abi)) void sll_api_sys_get_platform(sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_sandbox_flags_t sll_api_sys_get_sandbox_flags(void);
__attribute__((ms_abi)) void sll_api_sys_get_version(sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_sys_load_library(const sll_string_t* path);
__attribute__((ms_abi)) void sll_api_sys_remove_env(const sll_string_t* key);
__attribute__((ms_abi)) void sll_api_sys_set_env(const sll_string_t* key,const sll_string_t* value);
__attribute__((ms_abi)) void sll_api_sys_set_sandbox_flag(sll_sandbox_flag_t flag);
const sll_loaded_library_t*const* sll_get_loaded_libraries(sll_size_t* count);
void sll_set_argument(sll_array_length_t index,const sll_char_t* value);
void sll_set_argument_count(sll_array_length_t value);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_error_t sll_api_process_execute_shell(const sll_string_t* cmd);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_pid_t sll_api_process_get_pid(void);
__attribute__((ms_abi)) void sll_api_process_join(const sll_string_t*const* args,sll_arg_count_t arg_count,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_process_split(const sll_string_t* args,sll_array_t* out);
__attribute__((ms_abi)) void sll_api_process_start(const sll_array_t* args,const sll_string_t* cwd,sll_process_creation_flags_t flags,const sll_string_t* stdin,sll_array_t* out);
void sll_process_join_args(const sll_char_t*const* a,sll_string_t* o);
__attribute__((ms_abi)) void sll_api_math_abs(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_math_acos(sll_float_t a);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_math_acosh(sll_float_t a);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_math_asin(sll_float_t a);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_math_asinh(sll_float_t a);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_math_atan(sll_float_t a);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_math_atan2(sll_float_t y,sll_float_t x);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_math_atanh(sll_float_t a);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_math_cbrt(sll_float_t a);
__attribute__((ms_abi)) void sll_api_math_ceil(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_size_t sll_api_math_combinations(sll_size_t a,sll_size_t b);
__attribute__((ms_abi)) void sll_api_math_copy_sign(const sll_number_t* a,const sll_number_t* b,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_cos(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_cosh(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_size_t sll_api_math_euler_phi(sll_size_t n);
__attribute__((ms_abi)) void sll_api_math_exp(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_size_t sll_api_math_factorial(sll_size_t a);
__attribute__((ms_abi)) void sll_api_math_factors(sll_size_t a,sll_array_t* out);
__attribute__((ms_abi)) void sll_api_math_floor(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_math_gcd(sll_integer_t a,sll_integer_t b);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_size_t sll_api_math_int_log2(sll_size_t a);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_math_int_pow(sll_integer_t a,sll_size_t b,sll_size_t c);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_size_t sll_api_math_int_sqrt(sll_size_t v);
__attribute__((ms_abi)) void sll_api_math_log(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_log10(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_log2(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_size_t sll_api_math_permutations(sll_size_t a,sll_size_t b);
__attribute__((ms_abi)) void sll_api_math_pow(const sll_number_t* a,const sll_number_t* b,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_round(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_sin(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_sinh(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_sqrt(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_tan(const sll_number_t* a,sll_number_t* out);
__attribute__((ms_abi)) void sll_api_math_tanh(const sll_number_t* a,sll_number_t* out);
__attribute__((warn_unused_result)) sll_float_t sll_math_abs(sll_float_t a);
__attribute__((warn_unused_result)) sll_float_t sll_math_copy_sign(sll_float_t a,sll_float_t b);
__attribute__((warn_unused_result)) sll_factor_t* sll_math_factors(sll_size_t n,sll_array_length_t* ol);
__attribute__((warn_unused_result)) sll_float_t sll_math_mod(sll_float_t a,sll_float_t b);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_object_t* sll_api_object_new(const sll_string_t* format,sll_object_t*const* args,sll_arg_count_t lenngth);
__attribute__((ms_abi)) void sll_api_weakref__init(sll_object_t* no_object,sll_integer_t callback);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_weak_reference_t sll_api_weakref_create(sll_object_t* object);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_weakref_delete(sll_weak_reference_t wr);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_object_t* sll_api_weakref_get(sll_weak_reference_t wr);
__attribute__((ms_abi)) void sll_api_weakref_set_callback_data(sll_weak_reference_t wr,sll_object_t* callback);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_object_t* sll_api_sort_quicksort(sll_object_t* arr,sll_bool_t reverse,sll_bool_t inplace,sll_integer_t key_fn);
void sll_quicksort(sll_object_t** elements,sll_array_length_t length,sll_compare_result_t cmp,sll_integer_t key_fn);
__attribute__((ms_abi)) void sll_api_vm_get_config(sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_size_t sll_api_vm_get_instruction_count(void);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_instruction_index_t sll_api_vm_get_instruction_index(void);
__attribute__((ms_abi)) void sll_api_vm_get_location(sll_instruction_index_t instruction_index,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_reference_count_t sll_api_vm_get_ref_count(sll_object_t* object);
__attribute__((warn_unused_result)) sll_object_t* sll_instruction_to_location(sll_instruction_index_t instruction_index);
__attribute__((ms_abi)) void sll_api_hash_md5(unsigned int a,unsigned int b,unsigned int c,unsigned int d,const sll_string_t* str,sll_array_t* out);
__attribute__((ms_abi)) void sll_api_hash_sha1(unsigned int a,unsigned int b,unsigned int c,unsigned int d,unsigned int e,const sll_string_t* str,sll_array_t* out);
__attribute__((ms_abi)) void sll_api_hash_sha256(unsigned int a,unsigned int b,unsigned int c,unsigned int d,unsigned int e,unsigned int f,unsigned int g,unsigned int h,const sll_string_t* str,sll_array_t* out);
__attribute__((ms_abi)) void sll_api_hash_sha512(unsigned long long int a,unsigned long long int b,unsigned long long int c,unsigned long long int d,unsigned long long int e,unsigned long long int f,unsigned long long int g,unsigned long long int h,const sll_string_t* str,sll_array_t* out);
void sll_hash_md5(sll_md5_data_t* dt,void* bf,sll_size_t bfl);
void sll_hash_sha1(sll_sha1_data_t* dt,void* bf,sll_size_t bfl);
void sll_hash_sha256(sll_sha256_data_t* dt,void* bf,sll_size_t bfl);
void sll_hash_sha512(sll_sha512_data_t* dt,void* bf,sll_size_t bfl);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_float_t sll_api_random_get_float(sll_float_t min,sll_float_t max);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_random_get_int(sll_integer_t min,sll_integer_t max);
__attribute__((ms_abi)) void sll_api_random_get_string(sll_string_length_t len,sll_char_t min,sll_char_t max,sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_string_checksum_t sll_api_string_checksum(const sll_string_t* str);
__attribute__((ms_abi)) void sll_api_string_convert(sll_object_t*const* args,sll_arg_count_t len,sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_string_count(const sll_string_t* str,const sll_char_string_t* elem);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_string_count_left(const sll_string_t* str,sll_char_t chr);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_string_count_right(const sll_string_t* str,sll_char_t chr);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_string_ends(const sll_string_t* str,const sll_char_string_t* end);
__attribute__((ms_abi)) void sll_api_string_flip_case(const sll_string_t* str,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_format(const sll_string_t* fmt,sll_object_t*const* args,sll_arg_count_t len,sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_string_index(const sll_string_t* str,const sll_char_string_t* substr,sll_string_length_t start);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_string_index_list(const sll_string_t* str,const sll_char_string_t* substr,sll_bool_t inv);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_string_index_reverse(const sll_string_t* str,const sll_char_string_t* substr);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_integer_t sll_api_string_index_reverse_list(const sll_string_t* str,const sll_char_string_t* substr,sll_bool_t inv);
__attribute__((ms_abi)) void sll_api_string_join(const sll_char_string_t* infix,const sll_array_t* arr,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_pad(const sll_string_t* str,sll_string_length_t len,sll_char_t chr,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_pad_left(const sll_string_t* str,sll_string_length_t len,sll_char_t chr,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_pad_right(const sll_string_t* str,sll_string_length_t len,sll_char_t chr,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_replace(const sll_string_t* str,const sll_char_string_t* old,const sll_char_string_t* new,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_reverse(const sll_string_t* str,sll_string_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_string_secure_equal(const sll_string_t* a,const sll_string_t* b);
__attribute__((ms_abi)) void sll_api_string_split(const sll_string_t* str,const sll_char_string_t* infix,sll_array_t* out);
__attribute__((ms_abi)) __attribute__((warn_unused_result)) sll_bool_t sll_api_string_starts(const sll_string_t* str,const sll_char_string_t* start);
__attribute__((ms_abi)) void sll_api_string_to_lower_case(const sll_string_t* str,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_to_title_case(const sll_string_t* str,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_to_upper_case(const sll_string_t* str,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_trim(const sll_string_t* str,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_trim_left(const sll_string_t* str,sll_string_t* out);
__attribute__((ms_abi)) void sll_api_string_trim_right(const sll_string_t* str,sll_string_t* out);
__attribute__((warn_unused_result)) void* sll_allocate(sll_size_t size);
__attribute__((warn_unused_result)) void* sll_allocate_raw(sll_size_t size,sll_bool_t fail_on_error);
__attribute__((warn_unused_result)) void* sll_allocate_stack(sll_size_t size);
__attribute__((warn_unused_result)) void* sll_allocate_stack_raw(sll_size_t size,sll_bool_t fail_on_error);
void sll_deallocate(void* pointer);
void* sll_memory_move(void* pointer,sll_bool_t direction);
__attribute__((warn_unused_result)) void* sll_reallocate(void* pointer,sll_size_t size);
__attribute__((warn_unused_result)) void* sll_reallocate_raw(void* pointer,sll_size_t size,sll_bool_t fail_on_error);
__attribute__((warn_unused_result)) void* sll_zero_allocate(sll_size_t size);
__attribute__((warn_unused_result)) void* sll_zero_allocate_raw(sll_size_t size,sll_bool_t fail_on_error);
__attribute__((warn_unused_result)) void* sll_zero_allocate_stack(sll_size_t size);
__attribute__((warn_unused_result)) void* sll_zero_allocate_stack_raw(sll_size_t size,sll_bool_t fail_on_error);
__attribute__((warn_unused_result)) sll_object_type_t sll_add_type(sll_object_type_table_t* type_table,sll_object_t*const* object_data,sll_arg_count_t field_count,const sll_string_t* name);
__attribute__((warn_unused_result)) sll_object_t* sll_create_new_object_type(sll_object_type_table_t* type_table);
__attribute__((warn_unused_result)) sll_object_t* sll_create_object_type(const sll_object_type_table_t* type_table,sll_object_type_t type,sll_object_t*const* args,sll_arg_count_t arg_count);
void sll_free_object_type_list(sll_object_type_table_t* type_table);
__attribute__((warn_unused_result)) sll_arg_count_t sll_get_offset(const sll_object_type_table_t* type_table,sll_object_type_t type,const sll_string_t* field_name);
void sll_get_type_name(const sll_object_type_table_t* type_table,sll_object_type_t type,sll_string_t* out);
__attribute__((warn_unused_result)) sll_object_t* sll_object_clone(const sll_object_type_table_t* type_table,sll_object_t* object,sll_bool_t deep);
__attribute__((warn_unused_result)) sll_object_t* sll_object_get_field(const sll_object_type_table_t* type_table,sll_object_t* object,const sll_string_t* field_name);
void sll_object_set_field(const sll_object_type_table_t* type_table,sll_object_t* object,const sll_string_t* field_name,sll_object_t* value);
void sll_object_to_array(const sll_object_type_table_t* type_table,sll_object_t* object,sll_array_t* out);
void sll_object_to_map(const sll_object_type_table_t* type_table,sll_object_t* object,sll_map_t* out);
sll_file_offset_t sll_get_location(const sll_assembly_data_t* assembly_data,sll_instruction_index_t instruction_index,sll_string_index_t* file_path_string_index,sll_string_index_t* function_string_index);
void sll_get_name(sll_object_t* object,sll_string_t* out);
__attribute__((warn_unused_result)) sll_weak_reference_t sll_weakref_clone(sll_weak_reference_t wr);
__attribute__((warn_unused_result)) sll_weak_reference_t sll_weakref_create(sll_object_t* object);
__attribute__((warn_unused_result)) sll_bool_t sll_weakref_delete(sll_weak_reference_t wr);
__attribute__((warn_unused_result)) sll_object_t* sll_weakref_get(sll_weak_reference_t wr);
void sll_weakref_set_callback(sll_weak_reference_t wr,sll_weak_ref_destructor_t destructor,void* arg);
__attribute__((warn_unused_result)) sll_return_code_t sll_execute_assembly(const sll_assembly_data_t* assembly_data,const sll_vm_config_t* vm_config);
__attribute__((warn_unused_result)) sll_object_t* sll_execute_function(sll_integer_t function,sll_object_t*const* args,sll_arg_count_t arg_count,sll_execution_flags_t flags);
__attribute__((warn_unused_result)) sll_size_t sll_vm_get_instruction_count(void);
__attribute__((warn_unused_result)) sll_object_t* sll_wait_thread(sll_thread_index_t thread_index);
__attribute__((warn_unused_result)) sll_object_t* sll_array_length_to_object(sll_array_length_t length);
__attribute__((warn_unused_result)) sll_object_t* sll_array_to_object(const sll_array_t* array);
__attribute__((warn_unused_result)) sll_object_t* sll_array_to_object_nocopy(sll_array_t* array);
__attribute__((warn_unused_result)) sll_object_t* sll_char_to_object(sll_char_t char_);
__attribute__((warn_unused_result)) sll_object_t* sll_char_to_string_object(sll_char_t char_);
__attribute__((warn_unused_result)) sll_object_t* sll_complex_to_object(const sll_complex_t* complex_);
__attribute__((warn_unused_result)) sll_object_t* sll_float_to_object(sll_float_t float_);
__attribute__((warn_unused_result)) sll_object_t* sll_int_to_object(sll_integer_t int_);
__attribute__((warn_unused_result)) sll_object_t* sll_map_length_to_object(sll_map_length_t length);
__attribute__((warn_unused_result)) sll_object_t* sll_map_to_object(const sll_map_t* map);
__attribute__((warn_unused_result)) sll_object_t* sll_map_to_object_nocopy(sll_map_t* map);
__attribute__((warn_unused_result)) sll_object_t* sll_string_pointer_to_object(const sll_char_t* pointer);
__attribute__((warn_unused_result)) sll_object_t* sll_string_pointer_length_to_object(const sll_char_t* pointer,sll_string_length_t length);
__attribute__((warn_unused_result)) sll_object_t* sll_string_to_object(const sll_string_t* string);
__attribute__((warn_unused_result)) sll_object_t* sll_string_to_object_nocopy(sll_string_t* string);
void sll_deinit(void);
void sll_init(void);
void sll_register_cleanup(sll_cleanup_function_t function,sll_bool_t type);
void sll_clone_internal_function_table(sll_internal_function_table_t* internal_function_table,sll_internal_function_table_t* out);
void sll_create_internal_function_table(sll_internal_function_table_t* out);
void sll_free_internal_function_table(sll_internal_function_table_t* internal_function_table);
__attribute__((warn_unused_result)) sll_function_index_t sll_lookup_internal_function(const sll_internal_function_table_t* internal_function_table,const sll_char_t* name);
sll_function_index_t sll_register_internal_function(sll_internal_function_table_t* internal_function_table,const sll_char_t* name,const sll_char_t* format,sll_internal_function_pointer_t function);
void sll_register_internal_functions(sll_internal_function_table_t* internal_function_table,const sll_internal_function_descriptor_t* data,sll_function_index_t length);
__attribute__((warn_unused_result)) sll_bool_t sll_get_sandbox_flag(sll_sandbox_flag_t flag);
__attribute__((warn_unused_result)) sll_sandbox_flags_t sll_get_sandbox_flags(void);
void sll_set_sandbox_flag(sll_sandbox_flag_t flag);
__attribute__((warn_unused_result)) sll_float_t sll_complex_abs(const sll_complex_t* a);
void sll_complex_add(const sll_complex_t* a,const sll_complex_t* b,sll_complex_t* out);
void sll_complex_conjugate(const sll_complex_t* a,sll_complex_t* out);
void sll_complex_div(const sll_complex_t* a,const sll_complex_t* b,sll_complex_t* out);
void sll_complex_div_float(const sll_complex_t* a,sll_float_t b,sll_complex_t* out);
void sll_complex_exp(const sll_complex_t* a,sll_complex_t* out);
void sll_complex_log(const sll_complex_t* a,sll_complex_t* out);
void sll_complex_mult(const sll_complex_t* a,const sll_complex_t* b,sll_complex_t* out);
void sll_complex_mult_float(const sll_complex_t* a,sll_float_t b,sll_complex_t* out);
void sll_complex_neg(const sll_complex_t* a,sll_complex_t* out);
void sll_complex_pow(const sll_complex_t* a,const sll_complex_t* b,sll_complex_t* out);
void sll_complex_pow_float(const sll_complex_t* a,sll_float_t b,sll_complex_t* out);
void sll_complex_pow_int(const sll_complex_t* a,sll_integer_t b,sll_complex_t* out);
void sll_complex_reciprocal(const sll_complex_t* a,sll_complex_t* out);
void sll_complex_sub(const sll_complex_t* a,const sll_complex_t* b,sll_complex_t* out);
void sll_free_string(sll_string_t* string);
void sll_string_and(const sll_string_t* a,const sll_string_t* b,sll_string_t* out);
void sll_string_and_char(const sll_string_t* string,sll_char_t char_,sll_string_t* out);
void sll_string_calculate_checksum(sll_string_t* string);
void sll_string_clone(const sll_string_t* string,sll_string_t* out);
void sll_string_combinations(const sll_string_t* a,const sll_string_t* b,sll_array_t* out);
__attribute__((warn_unused_result)) sll_string_checksum_t sll_string_combine_checksums(sll_string_checksum_t a,sll_string_length_t length,sll_string_checksum_t b);
__attribute__((warn_unused_result)) sll_compare_result_t sll_string_compare(const sll_string_t* a,const sll_string_t* b);
__attribute__((warn_unused_result)) sll_compare_result_t sll_string_compare_array(const sll_string_t* string,const sll_array_t* array,sll_bool_t inv);
__attribute__((warn_unused_result)) sll_compare_result_t sll_string_compare_map(const sll_string_t* string,const sll_map_t* map,sll_bool_t inv);
__attribute__((warn_unused_result)) sll_compare_result_t sll_string_compare_pointer(const sll_char_t* a,const sll_char_t* b);
void sll_string_concat(const sll_string_t* a,const sll_string_t* b,sll_string_t* out);
void sll_string_concat_char(const sll_string_t* string,sll_char_t char_,sll_string_t* out);
void sll_string_concat_chars(sll_char_t a,sll_char_t b,sll_string_t* out);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_count(const sll_string_t* string,const sll_string_t* substring);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_count_char(const sll_string_t* string,sll_char_t char_);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_count_left(const sll_string_t* string,sll_char_t char_);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_count_right(const sll_string_t* string,sll_char_t char_);
void sll_string_create(sll_string_length_t length,sll_string_t* out);
void sll_string_decrease(sll_string_t* string,sll_string_length_t length);
void sll_string_duplicate(const sll_string_t* string,sll_integer_t count,sll_string_length_t extra,sll_string_t* out);
__attribute__((warn_unused_result)) sll_bool_t sll_string_ends(const sll_string_t* string,const sll_string_t* suffix);
__attribute__((warn_unused_result)) sll_bool_t sll_string_equal(const sll_string_t* a,const sll_string_t* b);
__attribute__((warn_unused_result)) sll_bool_t sll_string_equal_array(const sll_string_t* string,const sll_array_t* array);
__attribute__((warn_unused_result)) sll_bool_t sll_string_equal_map(const sll_string_t* string,const sll_map_t* map);
void sll_string_flip_case(const sll_string_t* string,sll_string_t* out);
void sll_string_format(const sll_char_t* format,sll_string_t* out,...);
void sll_string_format_list(const sll_char_t* format,sll_string_length_t format_length,sll_var_arg_list_t* va,sll_string_t* out);
void sll_string_from_char(sll_char_t char_,sll_string_t* out);
void sll_string_from_data(sll_object_t** object_data,sll_string_length_t object_count,sll_string_t* out);
void sll_string_from_int(sll_integer_t int_,sll_string_t* out);
void sll_string_from_pointer(const sll_char_t* pointer,sll_string_t* out);
void sll_string_from_pointer_length(const sll_char_t* pointer,sll_string_length_t length,sll_string_t* out);
__attribute__((warn_unused_result)) sll_char_t sll_string_get(const sll_string_t* string,sll_string_length_t index);
__attribute__((warn_unused_result)) sll_bool_t sll_string_includes(const sll_string_t* string,const sll_string_t* substring);
__attribute__((warn_unused_result)) sll_bool_t sll_string_includes_char(const sll_string_t* string,sll_char_t char_);
void sll_string_increase(sll_string_t* string,sll_string_length_t length);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_index(const sll_string_t* string,const sll_string_t* substring,sll_string_length_t start_index);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_index_char(const sll_string_t* string,sll_char_t char_,sll_bool_t inv,sll_string_length_t start_index);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_index_multiple(const sll_string_t* string,const sll_char_t* char_data,sll_string_length_t char_count,sll_bool_t inv);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_index_reverse(const sll_string_t* string,const sll_string_t* substring);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_index_reverse_char(const sll_string_t* string,sll_char_t char_,sll_bool_t inv);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_index_reverse_multiple(const sll_string_t* string,const sll_char_t* char_data,sll_string_length_t char_count,sll_bool_t inv);
sll_string_length_t sll_string_insert_pointer(const sll_char_t* pointer,sll_string_length_t index,sll_string_t* out);
sll_string_length_t sll_string_insert_pointer_length(const sll_char_t* pointer,sll_string_length_t length,sll_string_length_t index,sll_string_t* out);
void sll_string_inv(const sll_string_t* string,sll_string_t* out);
void sll_string_join(const sll_string_t* string,sll_object_t*const* object_data,sll_array_length_t object_count,sll_string_t* out);
void sll_string_join_char(sll_char_t char_,sll_object_t*const* object_data,sll_array_length_t object_count,sll_string_t* out);
__attribute__((warn_unused_result)) sll_string_length_t sll_string_length(const sll_char_t* pointer);
void sll_string_lower_case(const sll_string_t* string,sll_string_t* out);
void sll_string_op(const sll_string_t* a,const sll_string_t* b,sll_binary_operator_t operator,sll_string_t* out);
void sll_string_op_array(const sll_string_t* string,const sll_array_t* array,sll_binary_operator_t operator,sll_bool_t inv,sll_array_t* out);
void sll_string_op_map(const sll_string_t* string,const sll_map_t* map,sll_binary_operator_t operator,sll_bool_t inv,sll_map_t* out);
void sll_string_or(const sll_string_t* a,const sll_string_t* b,sll_string_t* out);
void sll_string_or_char(const sll_string_t* string,sll_char_t char_,sll_string_t* out);
void sll_string_pad(const sll_string_t* string,sll_string_length_t length,sll_char_t char_,sll_string_t* out);
void sll_string_pad_left(const sll_string_t* string,sll_string_length_t length,sll_char_t char_,sll_string_t* out);
void sll_string_pad_right(const sll_string_t* string,sll_string_length_t length,sll_char_t char_,sll_string_t* out);
__attribute__((warn_unused_result)) sll_char_t sll_string_parse_char(const sll_string_t* string);
__attribute__((warn_unused_result)) sll_float_t sll_string_parse_float(const sll_string_t* string);
__attribute__((warn_unused_result)) sll_integer_t sll_string_parse_int(const sll_string_t* string);
void sll_string_prepend_char(const sll_string_t* string,sll_char_t char_,sll_string_t* out);
void sll_string_remove(const sll_string_t* string,const sll_string_t* substring,sll_string_t* out);
void sll_string_replace(const sll_string_t* string,const sll_string_t* old,const sll_string_t* new,sll_string_t* out);
void sll_string_replace_char(const sll_string_t* string,sll_char_t old,sll_char_t new,sll_string_t* out);
void sll_string_resize(const sll_string_t* string,sll_integer_t delta,sll_string_t* out);
void sll_string_reverse(const sll_string_t* string,sll_string_t* out);
__attribute__((warn_unused_result)) sll_bool_t sll_string_secure_equal(const sll_string_t* a,const sll_string_t* b);
void sll_string_select(const sll_string_t* string,sll_integer_t start,sll_integer_t end,sll_integer_t step,sll_string_t* out);
void sll_string_set_char(sll_string_t* string,sll_char_t char_,sll_string_length_t index);
void sll_string_shift(const sll_string_t* string,sll_integer_t delta,sll_string_t* out);
void sll_string_split(const sll_string_t* string,const sll_string_t* substring,sll_array_t* o);
void sll_string_split_char(const sll_string_t* string,sll_char_t char_,sll_array_t* o);
__attribute__((warn_unused_result)) sll_bool_t sll_string_starts(const sll_string_t* string,const sll_string_t* prefix);
void sll_string_title_case(const sll_string_t* string,sll_string_t* out);
void sll_string_to_array(const sll_string_t* string,sll_array_t* out);
void sll_string_to_map(const sll_string_t* string,sll_map_t* out);
void sll_string_trim(const sll_string_t* string,sll_string_t* out);
void sll_string_trim_left(const sll_string_t* string,sll_string_t* out);
void sll_string_trim_right(const sll_string_t* string,sll_string_t* out);
void sll_string_upper_case(const sll_string_t* string,sll_string_t* out);
void sll_string_xor(const sll_string_t* a,const sll_string_t* b,sll_string_t* out);
void sll_string_xor_char(const sll_string_t* string,sll_char_t char_,sll_string_t* out);
#endif
